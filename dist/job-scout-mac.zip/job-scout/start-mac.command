#!/bin/bash
# Job Scout launcher for Mac. Double-click this file.
cd "$(dirname "$0")" || exit 1
clear
echo "=============================================="
echo "   Job Scout"
echo "=============================================="
echo

# --- Python 3.10+ ---
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "Python 3.10 or newer was not found."
  echo
  echo "1. Go to https://www.python.org/downloads/ and install the latest Python."
  echo "2. Then double-click start-mac.command again."
  echo
  read -r -p "Press Enter to close this window..."
  exit 1
fi

# --- one-time setup (own private environment inside this folder) ---
if [ ! -x ".venv/bin/python" ]; then
  echo "First-time setup - this takes a minute or two..."
  "$PY" -m venv .venv || { echo "Could not create the Python environment."; read -r -p "Press Enter to close..."; exit 1; }
fi
if [ ! -f ".venv/.deps-installed" ] || [ requirements-scout.txt -nt ".venv/.deps-installed" ]; then
  echo "Installing the tool's components..."
  .venv/bin/python -m pip install --quiet --disable-pip-version-check -r requirements-scout.txt \
    && touch .venv/.deps-installed \
    || { echo; echo "Install failed - check your internet connection and try again."; read -r -p "Press Enter to close..."; exit 1; }
fi

# --- token ---
echo
echo "Log in to ResumeToJob > Profile > 'Job scout access' > Generate token."
echo "Copy the token, then paste it here (Cmd+V) and press Enter."
echo "(Press Enter with nothing pasted to skip - you can also paste it in the browser page.)"
echo
read -r -p "Token: " RTJ_TOKEN
export RTJ_TOKEN

# --- open the browser once the server is up, then run ---
( sleep 4; open "http://127.0.0.1:5001" ) &
echo
echo "Job Scout is starting. Your browser will open in a few seconds."
echo "Keep this window OPEN while you use it. Close it (or press Ctrl+C) to quit."
echo
.venv/bin/python scout_app.py
echo
read -r -p "Job Scout stopped. Press Enter to close this window..."
