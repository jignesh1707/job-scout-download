# Job Scout — Quick Start

Searches Workday, Oracle, iCIMS, Greenhouse, SmartRecruiters (and USAJobs / Google if you add a key) for jobs matching your role and location, and saves the results to a CSV.

## Before you start (once)

1. **Python 3.10 or newer** must be installed. Get it from https://www.python.org/downloads/
   - **Windows:** on the first screen of the installer, tick **"Add python.exe to PATH"**.
2. **Get your access token** from ResumeToJob: log in → **Profile** → **"Job scout access"** → **Generate token** → copy it. (It is only shown once. Generate a new one any time.)

## Start the tool

**Windows:** double-click **`start-windows.bat`**

**Mac:** double-click **`start-mac.command`**
- First time only, Mac may say it can't verify the file. Right-click (or Control-click) the file → **Open** → **Open**.
- If it says the file can't be opened because it's not executable, open Terminal and run: `chmod +x ` then drag the file into the Terminal window and press Enter.

A black window opens and does the setup the first time (1–2 minutes, needs internet). Then it asks:

> **Token:**

Paste your token (Windows: right-click in the window · Mac: Cmd+V) and press **Enter**. Your browser opens to the Job Scout page, with your employer list already loaded.

**Keep the black window open while you use the tool** — closing it quits Job Scout. Next time, just double-click the same file again and paste a fresh token if needed.

> Skipped the token, or it didn't load? Paste it into **Step 1** on the Job Scout page and press **Fetch curated list**.

## Search

1. Type a **Role** (e.g. "data analyst") and a **Location** (e.g. "Austin, TX" — or leave it blank for anywhere in the US).
2. Tick the sources to search. Workday, Oracle, iCIMS, Greenhouse and SmartRecruiters use your employer list.
3. Click **Run search** and watch results come in live.
4. When it finishes, click **Download CSV**.

## Then: sponsorship check

Upload the CSV on ResumeToJob's **Bulk Sponsor Check** page. It shows which jobs are at known H-1B/visa sponsors, and eligible postings are added to ResumeToJob's job feed automatically.

## Good to know

- Your token works for a limited time and a limited number of fetches. If it stops working, generate a new one on your ResumeToJob Profile page.
- The employer list is kept in memory only and never saved to your computer, so you load it each time you start the tool.
- Every search's CSV is also saved in the `runs` folder inside this folder.
- Google and USAJobs are optional and need their own free/paid keys (see the **How to use this** panel inside the tool). Most students can ignore them.
- Click **"How to use this"** in the tool for details on every filter.

## Troubleshooting

- **"Python was not found"** — install Python (link above), then double-click the start file again. On Windows make sure "Add python.exe to PATH" was ticked; if you missed it, run the installer again and choose Modify/Repair.
- **Browser page doesn't load** — make sure the black window is still open, then go to http://127.0.0.1:5001
- **"Token rejected"** — it may be expired or used up; generate a new one on your ResumeToJob Profile page.
- **Port already in use** — Job Scout is probably already running in another window. Close it and start again.
