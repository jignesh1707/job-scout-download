@echo off
setlocal
cd /d "%~dp0"
title Job Scout
cls
echo ==============================================
echo    Job Scout
echo ==============================================
echo.

rem --- Python 3.10+ ---
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto nopython

rem --- one-time setup (own private environment inside this folder) ---
if not exist ".venv\Scripts\python.exe" (
  echo First-time setup - this takes a minute or two...
  %PY% -m venv .venv
  if errorlevel 1 goto fail
)
if not exist ".venv\.deps-installed" (
  echo Installing the tool's components...
  ".venv\Scripts\python.exe" -m pip install --quiet --disable-pip-version-check -r requirements-scout.txt
  if errorlevel 1 goto fail
  echo done> ".venv\.deps-installed"
)

rem --- token ---
echo.
echo Log in to ResumeToJob, open Profile, find "Job scout access" and click Generate token.
echo Copy the token, then paste it here (right-click in this window) and press Enter.
echo (Press Enter with nothing pasted to skip - you can also paste it in the browser page.)
echo.
set "RTJ_TOKEN="
set /p "RTJ_TOKEN=Token: "

rem --- open the browser once the server is up, then run ---
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://127.0.0.1:5001'"
echo.
echo Job Scout is starting. Your browser will open in a few seconds.
echo Keep this window OPEN while you use it. Close it to quit.
echo.
".venv\Scripts\python.exe" scout_app.py
echo.
echo Job Scout stopped.
pause
exit /b 0

:nopython
echo Python 3.10 or newer was not found.
echo.
echo 1. Go to https://www.python.org/downloads/ and install the latest Python.
echo    IMPORTANT: tick "Add python.exe to PATH" on the first screen of the installer.
echo 2. Then double-click start-windows.bat again.
echo.
pause
exit /b 1

:fail
echo.
echo Setup failed - check your internet connection and try again.
pause
exit /b 1
