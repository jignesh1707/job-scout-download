"""jobscout.textutil — turn posting HTML into readable plain text."""

import re

from bs4 import BeautifulSoup


def html_to_text(html):
    """Keep block structure, don't split lines on inline tags like <b> or <a>."""
    if not html:
        return ""
    if "<" not in html:                       # already plain text
        return _tidy(html)

    soup = BeautifulSoup(html, "lxml")
    for junk in soup(["script", "style"]):
        junk.decompose()
    for br in soup.find_all("br"):
        br.replace_with("\n")
    for li in soup.find_all("li"):
        li.insert_before("\n• ")
    for block in soup.find_all(["p", "div", "ul", "ol", "section", "table", "tr",
                                "h1", "h2", "h3", "h4", "h5", "h6"]):
        block.insert_after("\n")
    return _tidy(soup.get_text(""))


def _tidy(text):
    text = text.replace("\xa0", " ").replace("\u200b", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = "\n".join(line.strip() for line in text.split("\n"))
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def first(*values):
    """First non-empty value, stringified."""
    for v in values:
        if v not in (None, "", [], {}):
            return str(v).strip()
    return ""
