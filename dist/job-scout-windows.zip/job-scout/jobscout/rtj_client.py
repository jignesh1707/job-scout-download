"""jobscout.rtj_client — fetch the curated tenants list from ResumeToJob's
scout-access endpoint instead of reading a local tenants.json.

Deliberately does NOT go through `jobscout.net.Net`: that client's retry/
backoff/pacing exists to be polite to *scraping targets* and to swallow
transient failures into a generic "gave up" log line. This is a single
authenticated call to our own API — we want the real status code and
response body surfaced immediately (a 401 means "your token is bad", not
"try again slower"), not retried or hidden.

Fetched fresh into memory on every call. Nothing here writes to disk —
that's the whole point: the curated tenants list stays a server-mediated,
revocable grant rather than a file a student can freely redistribute.
"""

import requests

DEFAULT_API_URL = "https://resumetojob-api.fly.dev"


class RtjTokenError(Exception):
    """The server rejected the token (unknown / expired / revoked / exhausted),
    or the request couldn't reach it at all. Message is meant to be printed
    straight to the user — see scout.py / scout_app.py callers."""


def load_tenants_remote(token, api_url=DEFAULT_API_URL):
    """Fetch the curated tenants list over HTTPS using a scout-access token.

    Returns the same shape `scout.load_tenants()` returns:
    `{source_name: [entry, ...]}`. Raises `RtjTokenError` on any failure —
    never returns an empty dict silently, so a caller can't mistake "token
    rejected" for "no employers curated yet".
    """
    token = (token or "").strip()
    if not token:
        raise RtjTokenError("No --rtj-token given.")

    url = f"{api_url.rstrip('/')}/scout-access/tenants"
    try:
        resp = requests.get(
            url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=15,
        )
    except requests.RequestException as e:
        raise RtjTokenError(f"Could not reach {api_url}: {e}") from e

    if resp.status_code != 200:
        detail = _extract_detail(resp)
        raise RtjTokenError(f"Token rejected ({resp.status_code}): {detail}")

    try:
        body = resp.json()
    except ValueError as e:
        raise RtjTokenError(f"{url} did not return valid JSON") from e

    tenants = body.get("tenants") or {}
    remaining = body.get("fetches_remaining")
    if remaining is not None:
        print(f"  [rtj] {remaining} fetch(es) remaining on this token")
    return tenants


def _extract_detail(resp):
    """Best-effort human-readable message from an error response.

    The API's error envelope is `{"error": {"code", "message", "details"}}`
    (app/core/errors.py); fall back to the raw body if that shape isn't
    there (e.g. a proxy/edge error page).
    """
    try:
        body = resp.json()
        message = body.get("error", {}).get("message")
        if message:
            return message
    except ValueError:
        pass
    return resp.text[:200] if resp.text else "(no body)"


__all__ = ("DEFAULT_API_URL", "RtjTokenError", "load_tenants_remote")
