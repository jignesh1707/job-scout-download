"""
jobscout.claude.employer_names — canonical (sponsor-verdict) employer names
for known ATS tenants, keyed by career-site host + site path.

Without this, company_name in the output CSV is whatever workday.py /
oracle.py / icims.py fell back to when the tenant was added: the ATS
subdomain, title-cased (ms.wd5.myworkdayjobs.com -> "Ms",
bdx.wd1.myworkdayjobs.com -> "Bdx", fmr.wd1.myworkdayjobs.com -> "Fmr").
That's not a real company name, so a sponsor-verdict engine matching against
official employer names can't recognise it.

employer_names.csv (name_canonical, is_cap_exempt, ats_platform,
job_site_url, notes) is the source of truth: it maps each career site to the
real employer name(s) filed under it. Most hosts map to exactly one employer.
A handful of hosts are shared by more than one *distinct* legal entity (e.g.
cvshealth.wd1.myworkdayjobs.com covers Aetna, Caremark, CVS Pharmacy, CVS Rx
Services and CVS Shared Services) — for those we can't tell from the posting
alone which entity it was actually filed under, so we make a best single
guess: prefer the one row left with no disambiguating note, otherwise the
shortest candidate name. See AMBIGUOUS_SITES below for the full list this
produced, so a wrong guess can be corrected by hand later if it matters.
"""

import csv
import re
from pathlib import Path
from urllib.parse import urlparse

_CSV_PATH = Path(__file__).parent / "employer_names.csv"
_DUPLICATE_RE = re.compile(r"duplicate", re.I)


def _site_key(url):
    """(host, first-path-segment) both lower-cased — the same granularity
    workday/oracle/taleo career sites are actually split on (e.g. Accenture
    and Avanade share a host but use different site paths)."""
    u = urlparse(url or "")
    host = (u.netloc or "").lower()
    seg = u.path.strip("/").split("/")[0].lower() if u.path else ""
    return host, seg


def _best_guess(host, names, keep):
    """Deterministic single pick among several distinct real entities that
    share one career site: prefer the one row left with no disambiguating
    note; otherwise prefer whichever candidate name lines up with the ATS
    subdomain itself (e.g. host 'broadcom...' -> 'broadcom' over the
    2-letter 'ca'); otherwise the shortest reasonably-named candidate."""
    blank = [e["name"] for e in keep if not e["notes"] and e["name"] in names]
    if len(set(blank)) == 1:
        return blank[0]

    tenant = re.sub(r"[^a-z0-9]", "", host.split(".")[0].lower())
    if len(tenant) >= 4:
        aligned = [n for n in names
                   if (lambda flat: flat.startswith(tenant) or tenant.startswith(flat)
                       or flat in tenant or tenant in flat)
                   (re.sub(r"[^a-z0-9]", "", n.lower()))]
        if len(aligned) == 1:
            return aligned[0]
        if len(aligned) > 1:
            names = aligned
        elif len(names) > 1:
            # no full-name match — try just the candidates' leading word
            # against the tenant (e.g. "cvs" in "cvshealth" picks out the
            # "cvs ..." entries over an unrelated subsidiary like "caremark")
            word_aligned = [n for n in names
                            if len(n.split()[0]) >= 3
                            and tenant.startswith(n.split()[0])]
            if word_aligned:
                names = word_aligned

    sizable = [n for n in names if len(n) >= 4] or names
    return min(sizable, key=len)


def _load(path=_CSV_PATH):
    groups = {}
    if not path.exists():
        return {}
    with path.open(newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            key = _site_key(row.get("job_site_url", ""))
            if not key[0]:
                continue
            groups.setdefault(key, []).append({
                "name": (row.get("name_canonical") or "").strip(),
                "notes": (row.get("notes") or "").strip(),
                "is_dupe": bool(_DUPLICATE_RE.search(row.get("notes") or "")),
            })

    table, ambiguous = {}, {}
    for key, entries in groups.items():
        keep = [e for e in entries if not e["is_dupe"]] or entries
        seen, names = set(), []
        for e in keep:
            if e["name"] not in seen:
                seen.add(e["name"])
                names.append(e["name"])

        if len(names) == 1:
            table[key] = names[0]
            continue

        best = _best_guess(key[0], names, keep)
        table[key] = best
        ambiguous[key] = {"picked": best, "candidates": names}

    return table, ambiguous


_TABLE, AMBIGUOUS_SITES = _load()


def _tenant_key(host_or_tenant, site=""):
    """Build the same (host, site) key from what an adapter already has —
    a bare tenant string (icims), or a full host (workday/oracle)."""
    s = (host_or_tenant or "").lower().strip()
    s = re.sub(r"^https?://", "", s).rstrip("/")
    if "." not in s:
        # bare tenant (icims): the CSV records hosts like careers-<tenant>
        # or <weirdprefix>-<tenant>.icims.com, so match on the tail.
        for (host, seg) in _TABLE:
            if host.endswith(f"-{s}.icims.com") or host == f"{s}.icims.com":
                return (host, seg)
        return (f"careers-{s}.icims.com", site.lower())
    return (s, (site or "").lower())


def canonical_company(host_or_tenant, site="", fallback=""):
    """Real employer name for this tenant, or `fallback` if unrecognised."""
    key = _tenant_key(host_or_tenant, site)
    if key in _TABLE:
        return _TABLE[key]
    # retry ignoring the site segment, in case the caller's site path
    # doesn't exactly match what's in the CSV (e.g. differing case/suffix)
    host_only = [k for k in _TABLE if k[0] == key[0]]
    if len(host_only) == 1:
        return _TABLE[host_only[0]]
    return fallback
