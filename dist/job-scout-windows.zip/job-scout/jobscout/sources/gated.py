"""
Google Jobs — the one source here that plain HTTP can't reach without help.

This is a real adapter — it refuses honestly rather than shipping code that
returns nothing and looks broken. It works today if you supply a SerpAPI key.
"""

import os

from ..core import Job
from ..textutil import html_to_text, first


class Unavailable(Exception):
    pass


# --------------------------------------------------------------------------- #
# Google Jobs — works with a SerpAPI key
# --------------------------------------------------------------------------- #
GOOGLE_NOTE = """Google Jobs needs a SERP API key.

  Why:  "Google for Jobs" is a search-results feature, not a site with an
        API. Scraping Google results directly trips bot detection fast.
        Google's Cloud Talent Solution is for employers hosting their own
        listings, not for reading Google's aggregated results.

  Working route: SerpAPI's google_jobs engine (paid, with a free tier).
    set SERPAPI_KEY=your_key        (PowerShell: $env:SERPAPI_KEY="your_key")
  then run this source normally.
"""

SERPAPI = "https://serpapi.com/search.json"


def google_search(q, net, tenants, emit):
    key = os.environ.get("SERPAPI_KEY", "").strip()
    if not key:
        raise Unavailable(GOOGLE_NOTE)

    emit("log", msg="[google] via SerpAPI google_jobs")
    start, kept = 0, 0
    while kept < q.limit:
        params = {
            "engine": "google_jobs",
            "q": f"{q.role} {q.location_string()}".strip(),
            "location": q.location_string() or "United States",
            "hl": "en", "gl": "us",
            "api_key": key,
        }
        if start:
            params["start"] = start
        if q.posted in ("today", "24h"):
            params["chips"] = "date_posted:today"
        elif q.posted in ("3days",):
            params["chips"] = "date_posted:3days"
        elif q.posted in ("7days", "week"):
            params["chips"] = "date_posted:week"
        elif q.posted == "month":
            params["chips"] = "date_posted:month"

        data = net.get_json(SERPAPI, params=params)
        if not data:
            break
        if data.get("error"):
            raise Unavailable(f"SerpAPI said: {data['error']}")
        results = data.get("jobs_results") or []
        if not results:
            break

        for r in results:
            detected = r.get("detected_extensions") or {}
            job = Job(
                source="google",
                company_name=first(r.get("company_name")),
                job_title=first(r.get("title")),
                location=first(r.get("location")),
                posted_date=first(detected.get("posted_at"), r.get("posted_at")),
                job_url=first(r.get("share_link"),
                              (r.get("apply_options") or [{}])[0].get("link"),
                              r.get("related_links", [{}])[0].get("link")),
                job_id=first(r.get("job_id"))[:120],
                _full_description=html_to_text(first(r.get("description"))),
            )
            sched = str(detected.get("schedule_type") or "").lower()
            job.job_type = {"full-time": "fulltime", "part-time": "parttime",
                            "contractor": "contract", "internship": "internship",
                            "temp-to-hire": "temporary"}.get(sched, "")
            if detected.get("work_from_home"):
                job.work_type = "remote"
            yield job
            kept += 1
            if kept >= q.limit:
                break

        start += 10
        if not data.get("serpapi_pagination"):
            break
