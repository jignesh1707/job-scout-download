"""
Workday (myworkdayjobs.com)

Workday career sites are per-employer, so there is no global search — you point
this at a list of tenants. Each tenant exposes a JSON endpoint that the site's
own front end uses:

    POST https://{host}/wday/cxs/{tenant}/{site}/jobs
    GET  https://{host}/wday/cxs/{tenant}/{site}{externalPath}

This is the most reliable of all the sources here: real JSON, no bot wall.
"""

import re

from ..core import Job, interleave, per_employer_cap
from ..textutil import html_to_text, first
from ..employer_names import canonical_company

NAME = "workday"
SERVER_SIDE = ("keywords", "location (partial)")
PAGE = 20

URL_RE = re.compile(
    r"https?://(?P<host>[^/]*\.myworkdayjobs\.com)"
    r"(?:/(?:wday/cxs/)?(?P<tenant>[^/]+))?"
    r"(?:/(?P<lang>[a-z]{2}-[A-Z]{2}))?"
    r"/(?P<site>[^/?#]+)", re.I)


def parse_url(url):
    """Turn a pasted careers URL into a tenant config entry."""
    m = URL_RE.search(url or "")
    if not m:
        return None
    host = m.group("host")
    tenant = host.split(".")[0]
    site = m.group("site")
    if site and site.lower() in ("job", "jobs"):
        site = m.group("tenant") or site
    return {"company": canonical_company(host, site, tenant.title()),
            "host": host, "tenant": tenant, "site": site}


def _tenant_bits(cfg):
    host = cfg["host"].replace("https://", "").rstrip("/")
    tenant = cfg.get("tenant") or host.split(".")[0]
    return host, tenant, cfg.get("site", "External")


def _one_tenant(cfg, q, net, emit, cap):
    host, tenant, site = _tenant_bits(cfg)
    company = canonical_company(host, site) or cfg.get("company") or tenant.title()
    api = f"https://{host}/wday/cxs/{tenant}/{site}"
    # Internal bookkeeping only, not part of the SSE stream — lets the
    # caller count how many employers a run actually reached before it
    # stopped, so it can tell the user where to resume from next time.
    emit("tenant", source=NAME, company=company)
    emit("log", msg=f"[workday] {company} — up to {cap} jobs")

    # Everything below runs per-employer. If one tenant is gated (401/403),
    # unreachable, or throws anything unexpected, we log it and move on to
    # the next employer instead of letting the whole workday run die with it.
    try:
        offset, seen_here = 0, 0
        while seen_here < cap:
            body = {
                "appliedFacets": {},
                "limit": PAGE,
                "offset": offset,
                "searchText": q.role,
            }
            data = net.post_json(f"{api}/jobs", json=body,
                                 headers={"Content-Type": "application/json",
                                          "Accept": "application/json"})
            if not data:
                return
            postings = data.get("jobPostings") or []
            if not postings:
                return

            for p in postings:
                path = p.get("externalPath") or ""
                job = Job(
                    source=NAME,
                    company_name=company,
                    job_title=first(p.get("title")),
                    location=first(p.get("locationsText"), p.get("locations")),
                    posted_date=first(p.get("postedOn"), p.get("startDate")),
                    job_url=f"https://{host}/{site}{path}",
                    job_id=first(p.get("bulletFields", [""])[0] if p.get("bulletFields") else "",
                                 path.rsplit("_", 1)[-1]),
                )
                detail = net.get_json(f"{api}{path}",
                                      headers={"Accept": "application/json"}) or {}
                info = detail.get("jobPostingInfo") or {}
                job._full_description = html_to_text(info.get("jobDescription", ""))
                job.location = first(info.get("location"), job.location)
                job.posted_date = first(info.get("startDate"), job.posted_date)
                if info.get("externalUrl"):
                    job.job_url = info["externalUrl"]
                tt = (info.get("timeType") or "").lower()
                if "part" in tt:
                    job.job_type = "parttime"
                elif "full" in tt:
                    job.job_type = "fulltime"
                if info.get("remoteType"):
                    rt = info["remoteType"].lower()
                    job.work_type = ("remote" if "remote" in rt else
                                     "hybrid" if "hybrid" in rt else "onsite")
                yield job
                seen_here += 1
                if seen_here >= cap:
                    return

            offset += PAGE
            if offset >= int(data.get("total") or 0):
                return
    except Exception as e:                                      # noqa: BLE001
        emit("log", msg=f"  [workday] {company} failed "
                        f"({type(e).__name__}: {e}) — skipping this employer")


def search(q, net, tenants, emit):
    cap = per_employer_cap(q, len(tenants))
    emit("log", msg=f"[workday] {len(tenants)} employer(s), {cap} jobs each max")
    yield from interleave(_one_tenant(cfg, q, net, emit, cap) for cfg in tenants)
