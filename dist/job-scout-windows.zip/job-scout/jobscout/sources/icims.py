"""
iCIMS (careers-{tenant}.icims.com)

iCIMS portals are per-employer and return HTML, not JSON. The search page:

    GET https://careers-{tenant}.icims.com/jobs/search?ss=1&searchKeyword=...&pr={page}

iCIMS templates are heavily customised per employer, so the parser below works
from the job links outward rather than trusting any one CSS class to exist.
"""

import re

from bs4 import BeautifulSoup

from ..core import Job, interleave, per_employer_cap
from ..textutil import html_to_text, first
from ..employer_names import canonical_company

NAME = "icims"
SERVER_SIDE = ("keywords", "location")

# iCIMS sits behind AWS WAF Bot Control, which fingerprints the TLS/HTTP2
# handshake against the declared User-Agent; plain `requests` claiming to be
# Chrome gets a 405 captcha response. curl_cffi reproduces a real Chrome
# handshake so the request passes.
IMPERSONATE = "chrome124"

HOST_RE = re.compile(r"https?://(?:careers-)?([a-z0-9-]+)\.icims\.com", re.I)
JOB_HREF_RE = re.compile(r"/jobs/(\d+)/", re.I)


def parse_url(url):
    m = HOST_RE.search(url or "")
    if not m:
        return None
    tenant = m.group(1)
    return {"company": canonical_company(tenant, "", tenant.replace("-", " ").title()),
            "tenant": tenant}


def _clean(text):
    return re.sub(r"\s+", " ", (text or "")).strip()


def _parse_results(html, host, company):
    soup = BeautifulSoup(html, "lxml")
    out, seen = [], set()

    for a in soup.find_all("a", href=True):
        m = JOB_HREF_RE.search(a["href"])
        if not m:
            continue
        jid = m.group(1)
        title = _clean(a.get_text())
        if not title or jid in seen:
            continue
        seen.add(jid)

        # Location usually lives in a sibling/parent block near the title link
        location = ""
        holder = a.find_parent(["div", "li", "tr"])
        for _ in range(3):
            if holder is None:
                break
            node = holder.find(class_=re.compile(r"location|job-location", re.I))
            if node:
                location = _clean(node.get_text(" "))
                break
            holder = holder.parent

        href = a["href"]
        if href.startswith("/"):
            href = f"https://{host}{href}"
        out.append(Job(source=NAME, company_name=company, job_title=title,
                       location=location, job_url=href, job_id=jid))
    return out


def _description(net, url):
    html = net.get_html(url, headers={"Accept": "text/html"}, impersonate=IMPERSONATE)
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    node = (soup.find("div", class_=re.compile(r"iCIMS_JobContent|job-description", re.I))
            or soup.find("div", id=re.compile(r"jobDescription|job-description", re.I))
            or soup.find("article"))
    return html_to_text(str(node)) if node else ""


def _candidate_hosts(tenant):
    # iCIMS tenants are inconsistent about whether "careers-" is part of the
    # actual subdomain (careers-centralhealth.icims.com) or the tenant slug
    # already is the whole subdomain (hps-harvard.icims.com) — there's no
    # rule that predicts which, so probe both.
    if tenant.startswith("careers-"):
        bare = tenant[len("careers-"):]
        return [f"{tenant}.icims.com", f"{bare}.icims.com"]
    return [f"careers-{tenant}.icims.com", f"{tenant}.icims.com"]


def _fetch_page(net, host, q, page):
    # Many employers wrap the iCIMS results in their own marketing-site
    # chrome and load the actual listing HTML in an iframe. The plain
    # /jobs/search URL then returns that wrapper page with no job links at
    # all; in_iframe=1 is what the wrapper's own iframe requests and gets
    # the real results directly, so always request it that way.
    return net.get_html(
        f"https://{host}/jobs/search",
        params={"ss": 1, "searchKeyword": q.role,
                "searchLocation": q.city or q.state or "", "pr": page,
                "in_iframe": 1},
        headers={"Accept": "text/html"},
        impersonate=IMPERSONATE)


def _one_tenant(cfg, q, net, emit, cap):
    tenant = cfg.get("tenant") or cfg.get("host", "").split(".")[0]
    company = canonical_company(tenant, "") or cfg.get("company") or tenant.title()
    # Internal bookkeeping only, not part of the SSE stream — lets the
    # caller count how many employers a run actually reached before it
    # stopped, so it can tell the user where to resume from next time.
    emit("tenant", source=NAME, company=company)
    emit("log", msg=f"[icims] {company} — up to {cap} jobs")

    # Isolate this employer the same way workday/oracle now do: a failure
    # here (blocked, unreachable, unparsable page) is logged and skipped
    # rather than killing every other iCIMS tenant in the rotation.
    try:
        host = None
        page, kept = 1, 0
        while kept < cap and page <= 20:
            if host is None:
                # Prefer whichever candidate actually has job listings; a
                # candidate that's merely reachable (200, but 0 job links)
                # might be the wrong host rather than a genuine empty result,
                # so only fall back to it if no candidate has real listings.
                reachable = None
                for candidate in _candidate_hosts(tenant):
                    html = _fetch_page(net, candidate, q, page)
                    if not html:
                        continue
                    jobs = _parse_results(html, candidate, company)
                    if jobs:
                        host = candidate
                        break
                    if reachable is None:
                        reachable = (candidate, html, jobs)
                else:
                    if reachable is None:
                        break
                    host, html, jobs = reachable
            else:
                html = _fetch_page(net, host, q, page)
                if not html:
                    break
                jobs = _parse_results(html, host, company)
            if not jobs:
                break
            for job in jobs:
                job._full_description = _description(net, job.job_url)
                yield job
                kept += 1
                if kept >= cap:
                    return
            page += 1
    except Exception as e:                                      # noqa: BLE001
        emit("log", msg=f"  [icims] {company} failed "
                        f"({type(e).__name__}: {e}) — skipping this employer")


def search(q, net, tenants, emit):
    cap = per_employer_cap(q, len(tenants))
    emit("log", msg=f"[icims] {len(tenants)} employer(s), {cap} jobs each max")
    yield from interleave(_one_tenant(cfg, q, net, emit, cap) for cfg in tenants)
