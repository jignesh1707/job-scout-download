"""
USAJOBS — the official U.S. federal government jobs API.

    GET https://data.usajobs.gov/api/search
        ?Keyword=...&LocationName=...&ResultsPerPage=...&Page=...

Requires a free API key: register at https://developer.usajobs.gov/APIRequest/
and send both the key and your registered email on every request:

    Authorization-Key: <key>
    User-Agent: <the email you registered with>
    Host: data.usajobs.gov

Confirmed live: an unauthenticated request to this endpoint returns HTTP 401.

Site-wide (like google), not per-employer — there is exactly one USAJOBS,
covering every federal agency at once, so it needs no tenants.json entries.
"""

import os

from ..core import Job
from ..textutil import html_to_text, first
from .gated import Unavailable

NAME = "usajobs"
SERVER_SIDE = ("keywords", "location")
API = "https://data.usajobs.gov/api/search"
PAGE = 100

USAJOBS_NOTE = """USAJOBS needs a free API key.

  Why:  data.usajobs.gov requires every request to carry a registered email
        and an API key issued to that email — there is no anonymous access
        (confirmed: an unauthenticated request gets HTTP 401).

  Working route: register (instant, free) at
    https://developer.usajobs.gov/APIRequest/
  then set both, e.g. in PowerShell:
    $env:USAJOBS_API_KEY="your_key"
    $env:USAJOBS_EMAIL="the_email_you_registered_with"
  and run this source normally.
"""

SCHEDULE_MAP = {"full-time": "fulltime", "part-time": "parttime",
                "intermittent": "temporary", "seasonal": "temporary"}


def _job_type(schedules):
    for s in schedules or []:
        name = (s.get("Name") or "").lower()
        jt = SCHEDULE_MAP.get(name)
        if jt:
            return jt
    return ""


def search(q, net, tenants, emit):
    key = os.environ.get("USAJOBS_API_KEY", "").strip()
    email = os.environ.get("USAJOBS_EMAIL", "").strip()
    if not key or not email:
        raise Unavailable(USAJOBS_NOTE)

    emit("log", msg="[usajobs] via data.usajobs.gov")
    headers = {"Host": "data.usajobs.gov", "User-Agent": email,
               "Authorization-Key": key, "Accept": "application/json"}

    page, kept = 1, 0
    while kept < q.limit:
        params = {"ResultsPerPage": PAGE, "Page": page}
        if q.role:
            params["Keyword"] = q.role
        if (q.city or q.state) and not q.location_override:
            params["LocationName"] = (f"{q.city}, {q.state}" if q.city and q.state
                                      else (q.city or q.state))

        data = net.get_json(API, params=params, headers=headers)
        if not data:
            break
        result = data.get("SearchResult") or {}
        items = result.get("SearchResultItems") or []
        if not items:
            break

        for item in items:
            d = item.get("MatchedObjectDescriptor") or {}
            details = (d.get("UserArea") or {}).get("Details") or {}
            duties = details.get("MajorDuties") or []
            full_text = "\n\n".join(filter(None, [
                details.get("JobSummary", ""),
                "\n".join(duties) if duties else "",
                details.get("Qualifications", ""),
            ]))
            job = Job(
                source=NAME,
                company_name=first(d.get("OrganizationName"), d.get("DepartmentName")),
                job_title=first(d.get("PositionTitle")),
                location=first(d.get("PositionLocationDisplay")),
                posted_date=first(d.get("PublicationStartDate")),
                job_url=first(d.get("PositionURI")),
                job_id=first(d.get("PositionID")),
                job_type=_job_type(d.get("PositionSchedule")),
                _full_description=html_to_text(full_text),
            )
            yield job
            kept += 1
            if kept >= q.limit:
                break

        page += 1
        if kept >= int(result.get("SearchResultCountAll") or 0):
            break
