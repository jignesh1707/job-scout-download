"""
Oracle — two different products under one roof.

1. Oracle Recruiting Cloud / Fusion (*.oraclecloud.com):
       GET {host}/hcmRestApi/resources/latest/recruitingCEJobRequisitions
       GET {host}/hcmRestApi/resources/latest/recruitingCEJobRequisitionDetails
   Clean REST JSON. It even separates the qualifications from the description,
   which is exactly what we want for the output columns.

2. Legacy Taleo (*.taleo.net):
       POST {host}/careersection/rest/jobboard/searchjobs
   Older, messier, and the response shape varies by tenant, so the parser here
   is deliberately tolerant.
"""

import json
import re

from ..core import Job, interleave, per_employer_cap
from ..textutil import html_to_text, first
from ..employer_names import canonical_company

NAME = "oracle"
SERVER_SIDE = ("keywords", "location")

ORC_HOST_RE = re.compile(r"https?://([^/]*oraclecloud\.com)", re.I)
ORC_SITE_RE = re.compile(r"/sites/([^/?#]+)", re.I)
TALEO_HOST_RE = re.compile(r"https?://([^/]*\.taleo\.net)", re.I)


def parse_url(url):
    url = url or ""
    m = ORC_HOST_RE.search(url)
    if m:
        site = ORC_SITE_RE.search(url)
        host = m.group(1)
        site_val = site.group(1) if site else "CX_1"
        return {"kind": "orc", "host": host, "site": site_val,
                "company": canonical_company(host, site_val, host.split(".")[0].title())}
    m = TALEO_HOST_RE.search(url)
    if m:
        host = m.group(1)
        portal = re.search(r"/careersection/([^/?#]+)", url)
        portal_val = portal.group(1) if portal else ""
        return {"kind": "taleo", "host": host,
                "portal": portal_val,
                "company": canonical_company(host, portal_val, host.split(".")[0].title())}
    return None


# --------------------------------------------------------------------------- #
def _orc(cfg, q, net, emit, cap):
    host = cfg["host"].replace("https://", "").rstrip("/")
    site = cfg.get("site", "CX_1")
    company = canonical_company(host, site) or cfg.get("company") or host.split(".")[0].title()
    base = f"https://{host}/hcmRestApi/resources/latest"
    emit("log", msg=f"[oracle/orc] {company} — {host}")

    offset, kept = 0, 0
    while kept < cap:
        finder = (f"findReqs;siteNumber={site},limit=25,offset={offset},"
                  f"sortBy=POSTING_DATES_DESC")
        if q.role:
            finder += f",keyword={q.role}"
        if q.location_string() and not q.location_override:
            finder += f",locationId=,selectedLocationsVal={q.city or q.state}"
        # Without expand=requisitionList the API returns facet counts
        # (TotalJobsCount, categoriesFacet, ...) but omits the actual job
        # list, so every search silently came back empty.
        data = net.get_json(f"{base}/recruitingCEJobRequisitions",
                            params={"onlyData": "true", "finder": finder,
                                    "expand": "requisitionList"},
                            headers={"Accept": "application/json"})
        if not data:
            break
        items = (data.get("items") or [{}])[0]
        reqs = items.get("requisitionList") or []
        if not reqs:
            break

        for r in reqs:
            rid = first(r.get("Id"), r.get("RequisitionId"))
            job = Job(
                source=NAME,
                company_name=company,
                job_title=first(r.get("Title")),
                location=first(r.get("PrimaryLocation"), r.get("PrimaryLocationCountry")),
                posted_date=first(r.get("PostedDate"), r.get("PostingStartDate")),
                job_url=f"https://{host}/hcmUI/CandidateExperience/en/sites/{site}/job/{rid}",
                job_id=rid,
            )
            detail = net.get_json(
                f"{base}/recruitingCEJobRequisitionDetails",
                params={"expand": "all", "onlyData": "true",
                        "finder": f'ById;Id="{rid}",siteNumber={site}'},
                headers={"Accept": "application/json"}) or {}
            d = (detail.get("items") or [{}])[0]
            desc = html_to_text(first(d.get("ExternalDescriptionStr"), ""))
            quals = html_to_text(first(d.get("ExternalQualificationsStr"), ""))
            # Oracle hands us the split already — label it so the extractor keeps it
            job._full_description = desc + (f"\n\nQualifications:\n{quals}" if quals else "")
            if d.get("WorkplaceTypeCode"):
                code = str(d["WorkplaceTypeCode"]).lower()
                job.work_type = ("remote" if "remote" in code else
                                 "hybrid" if "hybrid" in code else "onsite")
            yield job
            kept += 1
            if kept >= cap:
                return
        offset += 25


PORTAL_ID_RE = re.compile(r"[?&]portal=(\d+)")


def _resolve_numeric_portal(net, host, portal_path):
    # The REST search endpoint's `portal` param is the site's internal
    # numeric ID (e.g. 4140483459), not the career-section name in the page
    # URL (e.g. "hww_cs_internal_global" — sometimes itself a short digit
    # string like "2", which looks numeric but isn't the same ID). That real
    # ID isn't in tenants.json — it's embedded in the landing page's JS
    # config — so always fetch the page once and scrape it out.
    html = net.get_html(f"https://{host}/careersection/{portal_path}/jobsearch.ftl",
                        params={"lang": "en"})
    if not html:
        return None
    m = PORTAL_ID_RE.search(html)
    return m.group(1) if m else None


# --------------------------------------------------------------------------- #
def _taleo(cfg, q, net, emit, cap):
    host = cfg["host"].replace("https://", "").rstrip("/")
    portal_path = cfg.get("portal", "")
    company = canonical_company(host, portal_path) or cfg.get("company") or host.split(".")[0].title()
    url = f"https://{host}/careersection/rest/jobboard/searchjobs"
    emit("log", msg=f"[oracle/taleo] {company} — {host}")

    portal = _resolve_numeric_portal(net, host, portal_path)
    if not portal:
        emit("log", msg=f"  [oracle] {company} — no active career section found, skipping")
        return

    page, kept = 1, 0
    while kept < cap:
        body = {
            "multilineEnabled": False,
            "sortingSelection": {"sortBySelectionParam": "3",
                                 "ascendingSortingOrder": "false"},
            "fieldData": {"fields": {"KEYWORD": q.role,
                                     "LOCATION": q.city or q.state or ""},
                          "valid": True},
            "filterSelectionParam": {"searchFilterSelections": []},
            "advancedSearchFiltersSelectionParam": {"searchFilterSelections": []},
            "pageNo": page,
        }
        data = net.post_json(url, params={"lang": "en", "portal": portal},
                             data=json.dumps(body),
                             headers={"Content-Type": "application/json",
                                      "Accept": "application/json",
                                      "X-Requested-With": "XMLHttpRequest"})
        if not data:
            break
        reqs = data.get("requisitionList") or []
        if not reqs:
            break

        for r in reqs:
            cols = r.get("column") or []
            rid = first(r.get("contestNo"), r.get("jobId"))
            job = Job(
                source=NAME,
                company_name=company,
                job_title=first(cols[0] if cols else "", r.get("title")),
                location=first(cols[1] if len(cols) > 1 else "", r.get("location")),
                posted_date=first(r.get("postedDate"), cols[2] if len(cols) > 2 else ""),
                job_url=f"https://{host}/careersection/{portal_path}/jobdetail.ftl?job={rid}",
                job_id=rid,
                _full_description=html_to_text(first(r.get("jobDescription"), "")),
            )
            yield job
            kept += 1
            if kept >= cap:
                return
        page += 1


def _one_tenant(cfg, q, net, emit, cap):
    kind = cfg.get("kind") or ("taleo" if "taleo.net" in cfg.get("host", "") else "orc")
    runner = _taleo if kind == "taleo" else _orc
    company = cfg.get("company") or cfg.get("host", "")
    # Internal bookkeeping only, not part of the SSE stream — lets the
    # caller count how many employers a run actually reached before it
    # stopped, so it can tell the user where to resume from next time.
    emit("tenant", source=NAME, company=company)

    # Isolate this employer: a 401/403 (Blocked), a dead DNS name, a reset
    # connection, or any parsing surprise on ONE tenant used to take down the
    # whole oracle run. Now it just logs and the rotation moves on.
    try:
        yield from runner(cfg, q, net, emit, cap)
    except Exception as e:                                      # noqa: BLE001
        emit("log", msg=f"  [oracle] {company} failed "
                        f"({type(e).__name__}: {e}) — skipping this employer")


def search(q, net, tenants, emit):
    cap = per_employer_cap(q, len(tenants))
    emit("log", msg=f"[oracle] {len(tenants)} employer(s), {cap} jobs each max")
    yield from interleave(_one_tenant(cfg, q, net, emit, cap) for cfg in tenants)
