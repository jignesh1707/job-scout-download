"""
Greenhouse (job-boards.greenhouse.io / boards.greenhouse.io)

Public, unauthenticated Job Board API — the same one most job aggregators
read from. No bot wall, no key needed. Confirmed live against
job-boards.greenhouse.io/doordashusa:

    GET https://boards-api.greenhouse.io/v1/boards/{board_token}/jobs?content=true

Returns every open posting for the company in one response (no pagination).
"""

import re

from ..core import Job, interleave, per_employer_cap, role_words, parse_posted
from ..textutil import html_to_text, first
from ..employer_names import canonical_company

NAME = "greenhouse"
SERVER_SIDE = ()
API_HOST = "job-boards.greenhouse.io"

URL_RE = re.compile(
    r"(?:https?://)?(?:job-boards\.|boards\.)?greenhouse\.io/(?P<token>[a-zA-Z0-9_-]+)",
    re.I)


def parse_url(url):
    m = URL_RE.search(url or "")
    if not m:
        return None
    token = m.group("token")
    company = canonical_company(API_HOST, token, token.replace("-", " ").title())
    return {"company": company, "token": token}


def _job_id(j):
    for m in j.get("metadata") or []:
        name = (m.get("name") or "").lower()
        if "requisition" in name or "req id" in name or "job id" in name:
            val = m.get("value")
            if val:
                return str(val)
    return first(j.get("requisition_id"), j.get("internal_job_id"), j.get("id"))


def _one_tenant(cfg, q, net, emit, cap):
    token = cfg["token"]
    company = canonical_company(API_HOST, token) or cfg.get("company") or token.title()
    # Internal bookkeeping only, not part of the SSE stream — lets the
    # caller count how many employers a run actually reached before it
    # stopped, so it can tell the user where to resume from next time.
    emit("tenant", source=NAME, company=company)
    emit("log", msg=f"[greenhouse] {company} — up to {cap} jobs")

    # Isolate this employer: a bad token, a dead board, or any parsing
    # surprise on ONE tenant used to take down the whole run. Now it just
    # logs and the rotation moves on.
    try:
        data = net.get_json(
            f"https://boards-api.greenhouse.io/v1/boards/{token}/jobs",
            params={"content": "true"},
            headers={"Accept": "application/json"})
        if not data:
            return
        jobs = data.get("jobs") or []
        kept = 0
        # The API has no server-side role/keyword search — it hands back
        # every open posting for the board in default order. Without a
        # local role check here, "up to cap" postings get examined and
        # counted against the per-employer cap regardless of whether they
        # match the role being searched for, so a low cap (common with many
        # employers) burns through on irrelevant jobs before ever reaching
        # a matching one. Filter by role first, same words core.passes()
        # itself checks, so only postings that could actually pass later
        # consume the cap.
        #
        # Same reasoning applies to the Posted window: now that posted_date
        # is truthful (see the first_published fix above), a role-matching
        # but stale posting would otherwise still burn a cap slot here, get
        # dropped later by core.passes() as too old, and potentially starve
        # out a genuinely recent match further down the list that never
        # gets examined because the cap was already spent. Check the date
        # cutoff the same way core.passes() does, before the cap counts it.
        role_terms = role_words(q.role)
        cutoff = q.posted_cutoff()
        for j in jobs:
            location = (j.get("location") or {}).get("name", "")
            job = Job(
                source=NAME,
                company_name=company,
                job_title=first(j.get("title")),
                location=first(location),
                # first_published is stable; updated_at gets touched on ANY
                # edit to a posting (typo fix, reopening, etc.), so preferring
                # it made months-old postings look freshly posted.
                posted_date=first(j.get("first_published"), j.get("updated_at")),
                job_url=first(j.get("absolute_url")),
                job_id=_job_id(j),
                _full_description=html_to_text(first(j.get("content"))),
            )
            if role_terms:
                haystack = f"{job.job_title}\n{job._full_description}".lower()
                if not all(w in haystack for w in role_terms):
                    continue
            if cutoff:
                when = parse_posted(job.posted_date)
                if when and when < cutoff:
                    continue
            yield job
            kept += 1
            if kept >= cap:
                return
    except Exception as e:                                      # noqa: BLE001
        emit("log", msg=f"  [greenhouse] {company} failed "
                        f"({type(e).__name__}: {e}) — skipping this employer")


def search(q, net, tenants, emit):
    cap = per_employer_cap(q, len(tenants))
    emit("log", msg=f"[greenhouse] {len(tenants)} employer(s), {cap} jobs each max")
    yield from interleave(_one_tenant(cfg, q, net, emit, cap) for cfg in tenants)
