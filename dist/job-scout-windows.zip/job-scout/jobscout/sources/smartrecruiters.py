"""
SmartRecruiters (careers.smartrecruiters.com/{companyId})

Public Postings API — confirmed live against careers.smartrecruiters.com/AECOM2:

    GET https://api.smartrecruiters.com/v1/companies/{companyId}/postings
        ?limit=100&offset=N
    GET https://api.smartrecruiters.com/v1/companies/{companyId}/postings/{id}

The list endpoint is paginated (totalFound/offset/limit) and already states
location.remote / location.hybrid explicitly. The detail endpoint carries
typeOfEmployment and the actual description under jobAd.sections.
"""

import re

from ..core import Job, interleave, per_employer_cap, role_words
from ..textutil import html_to_text, first
from ..employer_names import canonical_company

NAME = "smartrecruiters"
SERVER_SIDE = ()
API_HOST = "careers.smartrecruiters.com"
PAGE = 100

URL_RE = re.compile(
    r"(?:https?://)?(?:careers\.)?smartrecruiters\.com/(?P<company_id>[a-zA-Z0-9_-]+)",
    re.I)

EMPLOYMENT_MAP = {"full": "fulltime", "part": "parttime", "intern": "internship",
                  "temp": "temporary", "contract": "contract"}


def parse_url(url):
    m = URL_RE.search(url or "")
    if not m:
        return None
    company_id = m.group("company_id")
    company = canonical_company(API_HOST, company_id,
                                company_id.replace("-", " ").title())
    return {"company": company, "company_id": company_id}


def _job_type(label):
    low = (label or "").lower()
    for key, jt in EMPLOYMENT_MAP.items():
        if key in low:
            return jt
    return ""


def _description(detail):
    ja = (detail.get("jobAd") or {}).get("sections") or {}
    parts = []
    for key in ("jobDescription", "qualifications", "additionalInformation"):
        text = (ja.get(key) or {}).get("text") or ""
        if text:
            parts.append(text)
    return html_to_text("\n\n".join(parts))


def _one_tenant(cfg, q, net, emit, cap):
    company_id = cfg["company_id"]
    company = canonical_company(API_HOST, company_id) or cfg.get("company") or company_id.title()
    # Internal bookkeeping only, not part of the SSE stream — lets the
    # caller count how many employers a run actually reached before it
    # stopped, so it can tell the user where to resume from next time.
    emit("tenant", source=NAME, company=company)
    emit("log", msg=f"[smartrecruiters] {company} — up to {cap} jobs")

    base = f"https://api.smartrecruiters.com/v1/companies/{company_id}"
    # Isolate this employer: a dead companyId, a rate limit, or any parsing
    # surprise on ONE tenant used to take down the whole run. Now it just
    # logs and the rotation moves on.
    try:
        offset, kept = 0, 0
        # The server-side ?q= filter above is loose — it's a general search,
        # not "must contain every role word" — so it can still hand back
        # postings that don't actually satisfy core.passes()'s role check.
        # With a multi-word role ("data analyst") and a small per-employer
        # cap, near-misses from ?q= were enough to reproduce the original
        # 0-kept problem. Apply the same local backstop greenhouse.py uses,
        # once the description is available, so only postings that could
        # actually pass later consume the cap.
        role_terms = role_words(q.role)
        while kept < cap:
            # Push the role search server-side (confirmed live: ?q=data%20analyst
            # cuts totalFound from 5010 to 1518 on a real company) so the pages
            # we page through are already role-relevant — otherwise the
            # per-employer cap gets spent examining default-order postings
            # that the later local role filter in core.passes() just drops.
            params = {"limit": PAGE, "offset": offset}
            if q.role:
                params["q"] = q.role
            data = net.get_json(f"{base}/postings",
                                params=params,
                                headers={"Accept": "application/json"})
            if not data:
                return
            postings = data.get("content") or []
            if not postings:
                return

            for p in postings:
                pid = p.get("id")
                loc = p.get("location") or {}
                job = Job(
                    source=NAME,
                    company_name=company,
                    job_title=first(p.get("name")),
                    location=first(loc.get("fullLocation")),
                    posted_date=first(p.get("releasedDate")),
                    job_id=first(p.get("refNumber"), pid),
                )
                if loc.get("remote"):
                    job.work_type = "remote"
                elif loc.get("hybrid"):
                    job.work_type = "hybrid"
                elif "remote" in loc or "hybrid" in loc:
                    job.work_type = "onsite"

                detail = net.get_json(f"{base}/postings/{pid}",
                                      headers={"Accept": "application/json"}) or {}
                job.job_type = _job_type((detail.get("typeOfEmployment") or {}).get("label"))
                job._full_description = _description(detail)
                job.job_url = first(detail.get("postingUrl"),
                                    f"https://jobs.smartrecruiters.com/{company_id}/{pid}")
                if role_terms:
                    haystack = f"{job.job_title}\n{job._full_description}".lower()
                    if not all(w in haystack for w in role_terms):
                        continue
                yield job
                kept += 1
                if kept >= cap:
                    return

            offset += PAGE
            if offset >= int(data.get("totalFound") or 0):
                return
    except Exception as e:                                      # noqa: BLE001
        emit("log", msg=f"  [smartrecruiters] {company} failed "
                        f"({type(e).__name__}: {e}) — skipping this employer")


def search(q, net, tenants, emit):
    cap = per_employer_cap(q, len(tenants))
    emit("log", msg=f"[smartrecruiters] {len(tenants)} employer(s), {cap} jobs each max")
    yield from interleave(_one_tenant(cfg, q, net, emit, cap) for cfg in tenants)
