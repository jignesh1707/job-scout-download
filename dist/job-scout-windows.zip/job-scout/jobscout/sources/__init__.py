"""Registry of every source adapter."""

from . import workday, oracle, icims, gated, greenhouse, smartrecruiters, usajobs

SOURCES = {
    "workday": {"search": workday.search, "needs_tenants": True,
                "parse_url": workday.parse_url,
                "note": "Per-employer JSON API. The most reliable source here."},
    "oracle":  {"search": oracle.search, "needs_tenants": True,
                "parse_url": oracle.parse_url,
                "note": "Oracle Recruiting Cloud and legacy Taleo, per employer."},
    "icims":   {"search": icims.search, "needs_tenants": True,
                "parse_url": icims.parse_url,
                "note": "Per-employer HTML portal. Templates vary a lot."},
    "greenhouse": {"search": greenhouse.search, "needs_tenants": True,
                   "parse_url": greenhouse.parse_url, "output_mode": "keywords",
                   "note": "Public Job Board JSON API. Reliable, no bot wall."},
    "smartrecruiters": {"search": smartrecruiters.search, "needs_tenants": True,
                        "parse_url": smartrecruiters.parse_url, "output_mode": "keywords",
                        "note": "Public Postings JSON API. Reliable, structurally rich."},
    "usajobs": {"search": usajobs.search, "needs_tenants": False,
                "parse_url": None, "output_mode": "keywords",
                "env_gate": "USAJOBS_API_KEY",
                "note": "Official federal jobs API. Needs a free USAJOBS_API_KEY "
                        "and USAJOBS_EMAIL."},
    "google":  {"search": gated.google_search, "needs_tenants": False,
                "parse_url": None, "env_gate": "SERPAPI_KEY",
                "note": "Needs a SERPAPI_KEY environment variable."},
}

ALIASES = {"taleo": "oracle", "orc": "oracle", "myworkdayjobs": "workday",
           "googlejobs": "google", "google_jobs": "google",
           "greenhouse.io": "greenhouse", "smartrecruiters.com": "smartrecruiters"}


def resolve(name):
    n = (name or "").strip().lower()
    return ALIASES.get(n, n)


def detect_source(url):
    """Identify which adapter a pasted careers URL belongs to."""
    u = (url or "").lower()
    if "myworkdayjobs.com" in u:
        return "workday"
    if "icims.com" in u:
        return "icims"
    if "taleo.net" in u or "oraclecloud.com" in u:
        return "oracle"
    if "greenhouse.io" in u:
        return "greenhouse"
    if "smartrecruiters.com" in u:
        return "smartrecruiters"
    return None
