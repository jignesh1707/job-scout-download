"""jobscout.net — one polite HTTP client shared by every source adapter."""

import random
import time

import requests

try:
    from curl_cffi import requests as cffi_requests
except ImportError:
    cffi_requests = None

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0 Safari/537.36",
]

REQUEST_EXCEPTIONS = (requests.RequestException,)
if cffi_requests is not None:
    REQUEST_EXCEPTIONS += (cffi_requests.exceptions.RequestException,)


class Blocked(Exception):
    """Raised when a host is clearly refusing automated traffic."""


class Net:
    def __init__(self, sleep=1.5, proxy=None, timeout=25, max_retries=3, emit=None):
        self.sleep = sleep
        self.timeout = timeout
        self.max_retries = max_retries
        self.emit = emit or (lambda *a, **k: None)
        self.proxy = proxy
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": random.choice(USER_AGENTS),
            "Accept-Language": "en-US,en;q=0.9",
        })
        if proxy:
            self.session.proxies.update({"http": proxy, "https": proxy})
        self._impersonate_session = None

    def _impersonated_session(self):
        # Some hosts (e.g. iCIMS, behind AWS WAF Bot Control) fingerprint the
        # TLS/HTTP2 handshake and reject a plain `requests` connection that
        # merely claims a Chrome User-Agent header. curl_cffi reproduces a
        # real browser's TLS fingerprint so the claimed identity is honest.
        if cffi_requests is None:
            raise Blocked("curl_cffi is not installed; cannot impersonate a browser")
        if self._impersonate_session is None:
            self._impersonate_session = cffi_requests.Session()
            if self.proxy:
                self._impersonate_session.proxies.update({"http": self.proxy, "https": self.proxy})
        return self._impersonate_session

    def _pause(self):
        time.sleep(self.sleep + random.uniform(0, self.sleep * 0.5))

    def request(self, method, url, *, expect="json", impersonate=None, **kw):
        kw.setdefault("timeout", self.timeout)
        session = self._impersonated_session() if impersonate else self.session
        last = None
        for attempt in range(self.max_retries):
            self._pause()
            try:
                if impersonate:
                    r = session.request(method, url, impersonate=impersonate, **kw)
                else:
                    r = session.request(method, url, **kw)
            except REQUEST_EXCEPTIONS as e:
                last = str(e)
                time.sleep(3 * (attempt + 1))
                continue

            if r.status_code == 200:
                if expect == "json":
                    try:
                        return r.json()
                    except ValueError:
                        # A JSON endpoint returning HTML almost always means a
                        # bot-check page rather than a real payload.
                        raise Blocked(f"{url} returned HTML where JSON was expected")
                return r.text
            if r.status_code in (401, 403):
                raise Blocked(f"{url} refused the request (HTTP {r.status_code})")
            if r.status_code == 404:
                return None
            if r.status_code in (429, 500, 502, 503, 504):
                wait = (2 ** attempt) * 8 + random.uniform(0, 4)
                self.emit("log", msg=f"  HTTP {r.status_code}, waiting {wait:.0f}s")
                if not impersonate:
                    self.session.headers["User-Agent"] = random.choice(USER_AGENTS)
                time.sleep(wait)
                last = f"HTTP {r.status_code}"
                continue
            last = f"HTTP {r.status_code}"
            break
        self.emit("log", msg=f"  giving up on {url[:70]} ({last})")
        return None

    def get_json(self, url, **kw):
        return self.request("GET", url, expect="json", **kw)

    def post_json(self, url, **kw):
        return self.request("POST", url, expect="json", **kw)

    def get_html(self, url, **kw):
        return self.request("GET", url, expect="text", **kw)
