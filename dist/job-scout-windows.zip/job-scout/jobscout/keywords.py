"""
jobscout.keywords — match a job description against a curated skills list.

Used by adapters whose SOURCES registry entry sets output_mode="keywords"
(see core.finalize()): instead of full text or RESPONSIBILITIES/QUALIFICATIONS
sections, the output job_description column holds a short comma-separated
list of the skills/tools/technologies the posting actually mentions.
"""

import re
from pathlib import Path

_LIST_PATH = Path(__file__).parent / "skills_list.txt"


def _load_skills(path=_LIST_PATH):
    if not path.exists():
        return []
    terms = []
    for line in path.read_text(encoding="utf-8").splitlines():
        term = re.sub(r"(^|\s)#.*$", "", line).strip()
        if term:
            terms.append(term)
    return terms


# A handful of terms double as ordinary English words/verbs, so the plain
# case-insensitive whole-word match everything else gets fires on normal
# prose: "R&D experience", "a Go-getter", "You will go to meetings",
# "Excel at communication" all matched before this fix. For just these
# terms, match case-sensitively (skills are written "R"/"Go"/"Excel", not
# lowercase mid-sentence verbs) and exclude the specific idiomatic
# construction that still slips through capitalization alone (a
# sentence-initial "Go-getter" or "Excel at ..." is still capitalized).
# Genuine mentions ("Go (Golang)", "Proficient in R for ...",
# "Excel and PowerPoint") are unaffected.
_AMBIGUOUS_EXTRA = {
    "r": r"(?!&)",                         # "R&D", "R&B" — not the language
    "go": r"(?!-)",                        # "Go-getter", "go-to" — not Go
    "excel": r"(?!\s+(?:at|in|as)\b)",     # "excel at/in/as ..." — the verb
}


def _compile(skills):
    # Word-boundary match that still works for terms ending in + or #
    # (C++, C#) where \b doesn't apply, by excluding alnum/+/# on both
    # sides instead of relying on \b.
    out = []
    for term in skills:
        extra = _AMBIGUOUS_EXTRA.get(term.lower(), "")
        flags = 0 if extra else re.I
        out.append((term, re.compile(
            r"(?<![A-Za-z0-9+#])" + re.escape(term) + extra +
            r"(?![A-Za-z0-9+#])", flags)))
    return out


SKILLS = _load_skills()
_PATTERNS = _compile(SKILLS)


def extract_keywords(text):
    """Return a comma-separated list of skills_list.txt terms found in text."""
    if not text:
        return ""
    seen, found = set(), []
    for term, pattern in _PATTERNS:
        key = term.lower()
        if key in seen:
            continue
        if pattern.search(text):
            seen.add(key)
            found.append(term)
    return ", ".join(found)
