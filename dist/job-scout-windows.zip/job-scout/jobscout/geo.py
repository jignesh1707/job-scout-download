"""
jobscout.geo — offline US city geocoding + distance, for the location filter.

core.py's location_ok() needs to answer "is this job within N miles of the
city the user searched?" but almost none of these ATS sources return
anything geocodable server-side, and most job postings write their location
as free text in wildly different shapes ("10017-New York-1211 Avenue of the
Americas", "US-NY-New York", "AZ - Work from home", "Jersey City, NJ"...).

This module ships with a small offline US cities table (us_cities.csv —
~29.7k city/state pairs with lat/lon, trimmed from the MIT-licensed
kelvins/US-Cities-Database) so radius search works with no network calls and
no geocoding-API rate limits. Two entry points:

    geocode(city, state)   -> (lat, lon) | None   what the user typed
    find_in_text(location) -> (lat, lon) | None   what a job listing says

Neither is exact. A bare city name with no state and more than one match in
the US ("Springfield") can't be resolved safely, and messy or non-US text
("US-Nationwide-FIELD", "Bangalore, Karnataka") won't match anything. Callers
should treat None as "couldn't geocode this side" and fall back to plain
text matching rather than treating it as "zero miles away" or "infinitely
far".
"""

import csv
import re
from functools import lru_cache
from math import asin, cos, radians, sin, sqrt
from pathlib import Path

_DATA_PATH = Path(__file__).parent / "us_cities.csv"

US_STATE_ABBR = {
    "alabama": "al", "alaska": "ak", "arizona": "az", "arkansas": "ar",
    "california": "ca", "colorado": "co", "connecticut": "ct", "delaware": "de",
    "florida": "fl", "georgia": "ga", "hawaii": "hi", "idaho": "id",
    "illinois": "il", "indiana": "in", "iowa": "ia", "kansas": "ks",
    "kentucky": "ky", "louisiana": "la", "maine": "me", "maryland": "md",
    "massachusetts": "ma", "michigan": "mi", "minnesota": "mn",
    "mississippi": "ms", "missouri": "mo", "montana": "mt", "nebraska": "ne",
    "nevada": "nv", "new hampshire": "nh", "new jersey": "nj",
    "new mexico": "nm", "new york": "ny", "north carolina": "nc",
    "north dakota": "nd", "ohio": "oh", "oklahoma": "ok", "oregon": "or",
    "pennsylvania": "pa", "rhode island": "ri", "south carolina": "sc",
    "south dakota": "sd", "tennessee": "tn", "texas": "tx", "utah": "ut",
    "vermont": "vt", "virginia": "va", "washington": "wa",
    "west virginia": "wv", "wisconsin": "wi", "wyoming": "wy",
    "district of columbia": "dc",
}
_STATE_ABBR_TO_FULL = {v: k for k, v in US_STATE_ABBR.items()}
_ABBR_SET = {v.upper() for v in US_STATE_ABBR.values()}

EARTH_RADIUS_MILES = 3958.8


def _norm(s):
    """Lowercase, strip everything but letters/digits — so 'New York' and a
    typo like 'Newyork' normalise to the same key."""
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def state_code(state):
    """Accept a full state name or a 2-letter code, return the code (or '')."""
    s = (state or "").strip().lower()
    if not s:
        return ""
    if len(s) == 2:
        return s.upper() if s.upper() in _ABBR_SET else ""
    return US_STATE_ABBR.get(s, "").upper()


# --------------------------------------------------------------------------- #
# Dataset — loaded once, lazily
# --------------------------------------------------------------------------- #
_by_key = None          # {(norm_city, STATE): (lat, lon)}
_by_name = None         # {norm_city: [(STATE, lat, lon), ...]}


def _load():
    global _by_key, _by_name
    if _by_key is not None:
        return
    _by_key, _by_name = {}, {}
    if not _DATA_PATH.exists():
        return

    sums = {}  # (norm_city, STATE) -> [sum_lat, sum_lon, n]  (average duplicate rows)
    with _DATA_PATH.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                lat, lon = float(row["lat"]), float(row["lon"])
            except (KeyError, ValueError, TypeError):
                continue
            city = _norm(row.get("city", ""))
            st = (row.get("state") or "").strip().upper()
            if not city or not st:
                continue
            acc = sums.setdefault((city, st), [0.0, 0.0, 0])
            acc[0] += lat
            acc[1] += lon
            acc[2] += 1

    for (city, st), (slat, slon, n) in sums.items():
        lat, lon = slat / n, slon / n
        _by_key[(city, st)] = (lat, lon)
        _by_name.setdefault(city, []).append((st, lat, lon))


def haversine_miles(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(radians, (lat1, lon1, lat2, lon2))
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    return 2 * EARTH_RADIUS_MILES * asin(sqrt(a))


@lru_cache(maxsize=128)
def geocode(city, state):
    """Resolve a typed city (+ optional state) into (lat, lon), or None."""
    _load()
    city_n = _norm(city)
    st = state_code(state)
    if not city_n:
        return None

    if st:
        hit = _by_key.get((city_n, st))
        if hit:
            return hit

    matches = _by_name.get(city_n) or []
    if st:
        # A state was given: only accept a match IN that state. Falling back
        # to a same-named city in some other state (silently) is how you get
        # "Foster City" resolving to Michigan for a California search — wrong
        # coordinates are worse than no coordinates.
        matches = [m for m in matches if m[0] == st]
    if len(matches) == 1:
        return matches[0][1], matches[0][2]
    return None   # ambiguous (e.g. "Springfield" with no state) — refuse to guess


_STATE_TOKEN_RE = re.compile(r"(?<![A-Za-z])([A-Z]{2})(?![A-Za-z])")
_SPLIT_RE = re.compile(r"[,/|()\-‐‑‒–—―]")
_NUMERIC_RE = re.compile(r"^\d[\d-]*$")
_FULL_STATE_NAMES = sorted(US_STATE_ABBR, key=len, reverse=True)  # longest first


def _state_hint(text):
    """A state code (2-letter token like 'NY') or full state name ('New
    York') mentioned anywhere in the text, if any."""
    for m in _STATE_TOKEN_RE.finditer(text):
        if m.group(1) in _ABBR_SET:
            return m.group(1)
    low = text.lower()
    for name in _FULL_STATE_NAMES:
        if re.search(rf"\b{re.escape(name)}\b", low):
            return US_STATE_ABBR[name].upper()
    return ""


@lru_cache(maxsize=4096)
def find_in_text(location_text):
    """Best-effort: pull a known city out of a messy job-location string."""
    _load()
    text = (location_text or "").strip()
    if not text or not _by_name:
        return None

    hint = _state_hint(text)
    segments = [s.strip() for s in _SPLIT_RE.split(text) if s.strip()]
    segments.append(text)

    best = None  # (candidate_len, lat, lon)
    seen = set()
    for seg in segments:
        words = [w for w in seg.split() if not _NUMERIC_RE.match(w)]
        for n in (3, 2, 1):
            for i in range(len(words) - n + 1):
                # A single word only counts as a city candidate when it's the
                # WHOLE segment — pulling a lone word like "Park" out of the
                # middle of "Prestige Technology Park IV" is how an office
                # park in India ends up resolving to a town in Kansas.
                if n == 1 and len(words) > 1:
                    continue
                cand = " ".join(words[i:i + n])
                key = _norm(cand)
                if not key or len(key) < 3 or key in seen:
                    continue
                seen.add(key)
                matches = _by_name.get(key)
                if not matches:
                    continue
                if hint:
                    # A state hint that doesn't match any candidate for this
                    # name means this candidate isn't it — don't fall back to
                    # a same-named city in some other state.
                    matches = [m for m in matches if m[0] == hint]
                if len(matches) == 1 and (best is None or len(cand) > best[0]):
                    best = (len(cand), matches[0][1], matches[0][2])
    return (best[1], best[2]) if best else None


# --------------------------------------------------------------------------- #
# "Is this even a US posting?" — for the no-location-typed default
# --------------------------------------------------------------------------- #
# Full country names first — a principled, if incomplete, list of the ones
# actually likely to show up in a US employer's own job-location text. Bare
# ISO country codes are deliberately excluded ("IN" is India, but it's also
# Indiana — too ambiguous to guess from two letters) and so are Canadian
# province codes ("ON" collides with the English word "on"). "can" is
# matched instead, since Workday's "Toronto, ON, CAN" convention is common
# and a whole-word "can" almost never appears in a structured location field.
_NON_US_COUNTRIES = {
    "india", "china", "canada", "mexico", "malaysia", "philippines", "vietnam",
    "indonesia", "thailand", "singapore", "japan", "south korea", "korea",
    "taiwan", "hong kong", "pakistan", "bangladesh", "sri lanka", "nepal",
    "israel", "united arab emirates", "saudi arabia", "qatar", "egypt",
    "south africa", "nigeria", "kenya", "united kingdom", "ireland",
    "germany", "france", "spain", "italy", "portugal", "netherlands",
    "belgium", "switzerland", "austria", "sweden", "norway", "denmark",
    "finland", "poland", "czech republic", "czechia", "romania", "bulgaria",
    "hungary", "greece", "ukraine", "russia", "turkey", "brazil", "argentina",
    "chile", "colombia", "peru", "costa rica", "australia", "new zealand",
    "scotland", "wales", "can",
}
# Major non-US hubs that show up in these employers' listings without the
# country ever being spelled out — drawn from what these ATS portals
# actually write, not a guess at global coverage. Deliberately excludes
# single-word Western city names that double as real (if small) US
# town names — "Berlin", "Dublin", "London", "Manchester", "Geneva",
# "Vancouver", "Toronto" and the like are all real US places too, and a
# bare, state-less posting from one of them should never be dropped over a
# same-named city abroad. Toronto-with-no-country is still caught via the
# "can" signal above when a source writes it that way.
_NON_US_CITIES = {
    "bangalore", "bengaluru", "hyderabad", "pune", "chennai", "mumbai",
    "gurgaon", "gurugram", "noida", "kolkata", "new delhi",
    "shanghai", "beijing", "shenzhen", "hangzhou", "guangzhou",
    "manila", "kuala lumpur", "kulim", "penang",
    "tel aviv", "herzliya",
    "tokyo", "osaka", "seoul", "taipei", "hsinchu",
    "mexico city", "bogota", "sao paulo", "buenos aires",
}
_NON_US_CITIES_SORTED = sorted(_NON_US_CITIES, key=len, reverse=True)
_NON_US_COUNTRIES_SORTED = sorted(_NON_US_COUNTRIES, key=len, reverse=True)


def looks_non_us(location_text):
    """Best-effort: does this free-text location clearly point outside the
    US? Deliberately conservative, but in two tiers:

      1. A curated non-US city name (Hyderabad, Shanghai, Tel Aviv...) wins
         outright, before anything else is checked. These were picked
         specifically because they don't collide with real US town names,
         so there's no ambiguity to defer on — this is what lets
         "IN - Hyderabad_HQ" get caught as India even though "IN" alone
         reads as Indiana.
      2. Otherwise, a US state or city mention anywhere in the text wins —
         "United States - California - Foster City" or "AZ - Work from
         home" is never flagged. Only after that comes up empty does a
         country name (or "can") get checked.

    Ambiguous or unrecognised text (no signal either way — an address format
    this can't parse, a metro area not in either list) returns False. The
    point of this check is to catch the obviously-international postings
    that show up when no location was typed at all, not to demand proof of
    being in the US.
    """
    text = (location_text or "").strip()
    if not text:
        return False
    low = text.lower()

    def word_in(phrase):
        # (?<![A-Za-z0-9]) instead of \b — a plain \b treats "_" as a word
        # character, so it would miss "Hyderabad" inside "Hyderabad_HQ"
        # (a real Workday location string seen in practice).
        return re.search(rf"(?<![A-Za-z0-9]){re.escape(phrase)}(?![A-Za-z0-9])", low)

    if any(word_in(c) for c in _NON_US_CITIES_SORTED):
        return True
    if _state_hint(text) or find_in_text(text):
        return False
    return any(word_in(c) for c in _NON_US_COUNTRIES_SORTED)
