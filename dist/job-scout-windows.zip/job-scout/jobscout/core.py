"""
jobscout.core — shared data model, filters and output.

Every source adapter returns Job objects. All the filtering the user asked for
happens here, uniformly, so a filter behaves the same whether the source
supported it server-side or not.
"""

import csv
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import geo
from .keywords import extract_keywords

# --------------------------------------------------------------------------- #
# Canonical vocabularies
# --------------------------------------------------------------------------- #
LEVELS = ["internship", "entry", "associate", "mid", "senior", "director", "executive"]

LEVEL_PRESETS = {
    "any": [],
    "internship": ["internship"],
    "entry": ["internship", "entry"],
    "intermediate": ["associate", "mid"],
    "senior": ["senior", "director", "executive"],
}

JOB_TYPES = ["fulltime", "parttime", "contract", "temporary", "internship", "volunteer", "other"]
WORK_TYPES = ["onsite", "remote", "hybrid"]

POSTED_WINDOWS = {"today": 1, "24h": 1, "3days": 3, "7days": 7, "week": 7,
                  "14days": 14, "month": 31, "any": 0}


# --------------------------------------------------------------------------- #
# Query
# --------------------------------------------------------------------------- #
@dataclass
class Query:
    role: str = ""
    city: str = ""
    state: str = ""
    country: str = "United States"
    location_override: str = ""
    radius_miles: int = 25
    precise_radius: bool = False       # True only when the advanced exact
                                        # city/state/radius controls were used —
                                        # see location_ok() for what this switches

    level: str = "any"                 # preset name or comma list of LEVELS
    include: str = ""
    exclude: str = ""
    include_mode: str = "any"          # any | all
    match_scope: str = "both"          # title | description | both

    posted: str = "7days"
    limit: int = 25
    per_employer: int = 0              # 0 = split the limit evenly

    job_types: str = ""                # comma list of JOB_TYPES
    work_types: str = ""               # comma list of WORK_TYPES
    min_salary: int = 0                # annual USD floor
    companies: str = ""
    companies_exclude: str = ""

    description_mode: str = "sections"  # sections | full
    max_description_chars: int = 0

    sleep: float = 1.5
    proxy: str = ""

    # ---- derived helpers -------------------------------------------------- #
    def location_string(self):
        if self.location_override.strip():
            return self.location_override.strip()
        return ", ".join(p.strip() for p in (self.city, self.state, self.country)
                         if p and p.strip())

    def wanted_levels(self):
        if self.level in LEVEL_PRESETS:
            return set(LEVEL_PRESETS[self.level])
        return {v.strip().lower() for v in self.level.split(",") if v.strip()}

    def _csv(self, raw):
        return [v.strip().lower() for v in str(raw or "").split(",") if v.strip()]

    def wanted_job_types(self):
        return set(self._csv(self.job_types))

    def wanted_work_types(self):
        return set(self._csv(self.work_types))

    def include_terms(self):
        return self._csv(self.include)

    def exclude_terms(self):
        return self._csv(self.exclude)

    def company_allow(self):
        return self._csv(self.companies)

    def company_deny(self):
        return self._csv(self.companies_exclude)

    def posted_cutoff(self):
        days = POSTED_WINDOWS.get(self.posted, 0)
        if not days:
            return None
        return datetime.now(timezone.utc) - timedelta(days=days)


# --------------------------------------------------------------------------- #
# Job
# --------------------------------------------------------------------------- #
@dataclass
class Job:
    source: str = ""
    company_name: str = ""
    job_title: str = ""
    location: str = ""
    job_url: str = ""
    posted_date: str = ""              # ISO date when known
    job_description: str = ""          # shaped for output
    responsibilities: str = ""
    qualifications: str = ""
    job_type: str = ""
    work_type: str = ""
    level: str = ""
    salary_min: int = 0
    salary_max: int = 0
    job_id: str = ""
    inferred: str = ""                 # which fields we guessed from text
    _full_description: str = field(default="", repr=False)

    def dedupe_key(self):
        def norm(s):
            return re.sub(r"[^a-z0-9]+", "", (s or "").lower())
        loc = (self.location or "").split(",")[0]
        return (norm(self.company_name), norm(self.job_title), norm(loc))


# --------------------------------------------------------------------------- #
# Description shaping (same logic as the LinkedIn scraper)
# --------------------------------------------------------------------------- #
RESP_PATTERNS = (
    "responsibilit", "what you'll do", "what you will do", "what youll do",
    "what you'll be doing", "the role", "in this role", "role overview",
    "day to day", "day-to-day", "your impact", "the impact you", "duties",
    "job duties", "essential functions", "key accountabilities", "what you'll own",
    "scope of work", "your role", "position summary", "job summary",
    "primary functions", "core responsibilities", "a day in the life",
    "what the job entails", "you will",
)
QUAL_PATTERNS = (
    "qualification", "requirement", "what you'll need", "what you need",
    "what we're looking for", "what were looking for", "who you are",
    "skills", "experience", "must have", "must-have", "nice to have",
    "nice-to-have", "minimum", "preferred", "basic qualification",
    "ideal candidate", "your background", "education", "competencies",
    "we're looking for", "you have", "you bring", "desired",
)
STOP_PATTERNS = (
    "about us", "about the company", "about our", "who we are", "our mission",
    "our story", "our values", "our culture", "why join", "why work",
    "benefit", "perks", "what we offer", "compensation", "salary range",
    "pay range", "pay transparency", "equal opportunity", "equal employment",
    "eeo", "e-verify", "diversity", "accommodation", "how to apply",
    "application process", "additional information", "disclaimer", "notice",
    "privacy", "background check", "physical demands", "work environment",
    "travel requirement", "next steps", "our commitment", "legal",
)
ALL_PATTERNS = RESP_PATTERNS + QUAL_PATTERNS + STOP_PATTERNS
BULLET_CHARS = "•*-–—‣▪◦"
_MINOR = {"a", "an", "and", "at", "by", "for", "from", "in", "of", "on", "or",
          "the", "to", "with", "we", "you", "your", "our", "us", "be", "is"}


def _looks_like_label(s):
    words = s.split()
    if not words or len(words) > 8 or s.endswith((".", "!", "?", ",")):
        return False
    letters = [c for c in s if c.isalpha()]
    if letters and all(c.isupper() for c in letters):
        return True
    content = [w for w in words if w.strip("():").lower() not in _MINOR]
    return bool(content) and all(w[:1].isupper() for w in content)


def _is_heading(line):
    s = line.strip()
    if not s or len(s) > 90 or s[0] in BULLET_CHARS:
        return False
    if s.endswith(":"):
        return True
    low = s.rstrip(":").lower()
    return any(p in low for p in ALL_PATTERNS) and _looks_like_label(s)


def _classify(heading):
    h = heading.strip().rstrip(":").lower()
    if any(p in h for p in STOP_PATTERNS):
        return None
    if any(p in h for p in RESP_PATTERNS):
        return "resp"
    if any(p in h for p in QUAL_PATTERNS):
        return "qual"
    return None


def extract_sections(text):
    if not text:
        return "", ""
    buckets = {"resp": [], "qual": []}
    current = None
    for line in text.split("\n"):
        if _is_heading(line):
            current = _classify(line)
            if current:
                buckets[current].append(line.strip().rstrip(":") + ":")
            continue
        if current and line.strip():
            buckets[current].append(line.rstrip())

    def clean(lines):
        out = []
        for i, line in enumerate(lines):
            nxt = lines[i + 1] if i + 1 < len(lines) else None
            if line.endswith(":") and (nxt is None or nxt.endswith(":")):
                continue
            out.append(line)
        return "\n".join(out).strip()

    return clean(buckets["resp"]), clean(buckets["qual"])


def shape_description(full_text, mode="sections", max_chars=0):
    resp, qual = extract_sections(full_text)
    note = ""
    if mode == "sections":
        parts = []
        if resp:
            parts.append("RESPONSIBILITIES\n" + resp)
        if qual:
            parts.append("QUALIFICATIONS\n" + qual)
        desc = "\n\n".join(parts) if parts else full_text
        if not parts:
            note = "no sections found, kept full text"
    else:
        desc = full_text
    if max_chars and len(desc) > max_chars:
        desc = desc[:max_chars].rstrip() + " …[truncated]"
    return desc, resp, qual, note


# --------------------------------------------------------------------------- #
# Enrichment — fill in what the source didn't tell us
# --------------------------------------------------------------------------- #
LEVEL_HINTS = [
    ("internship", (r"\bintern\b", r"\binternship\b", r"\bco-?op\b")),
    ("executive",  (r"\bchief\b", r"\bc[teof]o\b", r"\bpresident\b", r"\bevp\b", r"\bsvp\b")),
    ("director",   (r"\bdirector\b", r"\bhead of\b", r"\bvp\b", r"\bvice president\b")),
    ("senior",     (r"\bsenior\b", r"\bsr\.?\b", r"\bstaff\b", r"\bprincipal\b",
                    r"\blead\b", r"\biv\b", r"\bl[5-9]\b")),
    ("entry",      (r"\bjunior\b", r"\bjr\.?\b", r"\bentry.level\b", r"\bassociate i\b",
                    r"\bgraduate\b", r"\bnew grad\b", r"\btrainee\b", r"\bapprentice\b")),
    ("associate",  (r"\bassociate\b", r"\bii\b", r"\banalyst\b")),
]

JOBTYPE_HINTS = [
    ("internship", (r"\bintern(ship)?\b", r"\bco-?op\b")),
    ("contract",   (r"\bcontract\b", r"\bcontractor\b", r"\bc2c\b", r"\bw2 contract\b",
                    r"\b1099\b", r"\bfreelance\b", r"\bconsultant\b")),
    ("temporary",  (r"\btemp(orary)?\b", r"\bseasonal\b")),
    ("parttime",   (r"\bpart[- ]time\b", r"\bpart time\b")),
    ("volunteer",  (r"\bvolunteer\b", r"\bpro bono\b")),
    ("fulltime",   (r"\bfull[- ]time\b", r"\bfull time\b", r"\bpermanent\b")),
]

REMOTE_RE = re.compile(r"\bremote\b|\bwork from home\b|\bwfh\b|\banywhere\b|\bdistributed\b", re.I)
HYBRID_RE = re.compile(r"\bhybrid\b|\bflexible on-?site\b", re.I)
ONSITE_RE = re.compile(r"\bon-?site\b|\bin[- ]office\b|\bin person\b", re.I)

SALARY_RE = re.compile(
    r"\$\s?(\d{2,3}(?:,\d{3})|\d{2,3}(?:\.\d+)?\s?[kK]|\d{2,7})"
    r"(?:\s?(?:-|–|to)\s?\$?\s?(\d{2,3}(?:,\d{3})|\d{2,3}(?:\.\d+)?\s?[kK]|\d{2,7}))?"
    r"\s*(per hour|/\s?hour|/\s?hr|an hour|hourly|per year|/\s?year|/\s?yr|annually)?",
    re.I)


def _money(tok):
    if not tok:
        return 0
    t = tok.replace(",", "").replace("$", "").strip()
    if t.lower().endswith("k"):
        try:
            return int(float(t[:-1]) * 1000)
        except ValueError:
            return 0
    try:
        return int(float(t))
    except ValueError:
        return 0


def parse_salary(text):
    """Best-effort annual USD range from free text. Hourly is annualised x2080."""
    if not text:
        return 0, 0
    best = (0, 0)
    for m in SALARY_RE.finditer(text[:4000]):
        lo, hi, unit = _money(m.group(1)), _money(m.group(2)), (m.group(3) or "").lower()
        if not lo:
            continue
        hourly = any(k in unit for k in ("hour", "hr"))
        if not unit and lo < 300:          # bare "$65 - $85" reads as hourly
            hourly = True
        if hourly:
            lo, hi = lo * 2080, hi * 2080
        if lo < 10000 or lo > 2000000:     # not a plausible annual figure
            continue
        if lo > best[0]:
            best = (lo, hi or lo)
    return best


def enrich(job):
    """Infer level, job type, work type and salary when the source omitted them."""
    guessed = []
    haystack = f"{job.job_title}\n{job.location}\n{job._full_description or job.job_description}"
    title = job.job_title or ""

    if not job.level:
        for level, pats in LEVEL_HINTS:
            if any(re.search(p, title, re.I) for p in pats):
                job.level = level
                guessed.append("level")
                break
        else:
            job.level = "mid"
            guessed.append("level")

    if not job.job_type:
        for jt, pats in JOBTYPE_HINTS:
            if any(re.search(p, haystack[:2500], re.I) for p in pats):
                job.job_type = jt
                guessed.append("job_type")
                break
        else:
            job.job_type = "fulltime"
            guessed.append("job_type")

    if not job.work_type:
        head = f"{title}\n{job.location}"
        if HYBRID_RE.search(head) or HYBRID_RE.search(haystack[:1500]):
            job.work_type = "hybrid"
        elif REMOTE_RE.search(head):
            job.work_type = "remote"
        elif ONSITE_RE.search(head):
            job.work_type = "onsite"
        elif REMOTE_RE.search(haystack[:1500]):
            job.work_type = "remote"
        else:
            job.work_type = "onsite"
        guessed.append("work_type")

    if not job.salary_min:
        lo, hi = parse_salary(job._full_description or job.job_description)
        if lo:
            job.salary_min, job.salary_max = lo, hi
            guessed.append("salary")

    job.inferred = ",".join(guessed)
    return job


# --------------------------------------------------------------------------- #
# Filtering
# --------------------------------------------------------------------------- #
def parse_posted(value):
    """Accept ISO dates, epoch millis, and phrases like '3 days ago'."""
    if not value:
        return None
    if isinstance(value, (int, float)) or (isinstance(value, str) and value.isdigit()):
        n = float(value)
        if n > 1e11:
            n /= 1000.0
        try:
            return datetime.fromtimestamp(n, tz=timezone.utc)
        except (ValueError, OSError):
            return None
    s = str(value).strip()
    m = re.search(r"(\d+)\+?\s*(minute|hour|day|week|month)s?\s*ago", s, re.I)
    if m:
        n, unit = int(m.group(1)), m.group(2).lower()
        mult = {"minute": 1 / 1440, "hour": 1 / 24, "day": 1, "week": 7, "month": 31}[unit]
        return datetime.now(timezone.utc) - timedelta(days=n * mult)
    if re.search(r"today|just posted|new\b", s, re.I):
        return datetime.now(timezone.utc)
    if re.search(r"yesterday", s, re.I):
        return datetime.now(timezone.utc) - timedelta(days=1)
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f",
                "%m/%d/%Y", "%d/%m/%Y", "%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s[:len(fmt) + 6].rstrip("Z"), fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


_ROLE_STOPWORDS = {"a", "an", "and", "or", "the", "of", "for", "in", "on", "at",
                    "to", "with", "&"}


def role_words(role):
    """Significant words from the role text, for a local relevance backstop.

    Source-side keyword search (Workday, Taleo, iCIMS...) is often loose — it
    can hand back postings that don't actually contain the words you typed
    ("Lead Midrange Engineer" for a "data analyst" search, say). This gives
    every job a local check: every significant word in the role text has to
    show up somewhere in the title or description, or the job is dropped.
    """
    return [w for w in re.findall(r"[a-z0-9+#]+", (role or "").lower())
            if len(w) > 1 and w not in _ROLE_STOPWORDS]


def keyword_ok(haystack, include, exclude, mode):
    h = (haystack or "").lower()
    if exclude and any(k in h for k in exclude):
        return False
    if include:
        hits = [k in h for k in include]
        return all(hits) if mode == "all" else any(hits)
    return True


US_STATE_ABBR = geo.US_STATE_ABBR             # kept as an alias — other code/tests may import it from here
_STATE_ABBR_TO_FULL = {v: k for k, v in US_STATE_ABBR.items()}


def _loc_contains(loc, phrase):
    """Whole-word/phrase, case-insensitive containment check against free text."""
    phrase = phrase.strip()
    if not phrase:
        return False
    return re.search(rf"\b{re.escape(phrase)}\b", loc) is not None


DEFAULT_RADIUS_MILES = 25


def location_ok(job, q):
    """Local backstop for city/state — most sources don't actually enforce this
    server-side (Workday's own search API, for one, is never given a location
    at all), so without this check the location fields in the UI are purely
    decorative and results come back from anywhere in the world.

    A free-text location override (q.location_override) is left alone — it's
    an explicit "trust this string, don't check it" escape hatch, too
    open-ended to verify reliably here. A job tagged remote is always let
    through — remote roles aren't tied to the city you searched.

    Otherwise there are two modes, chosen by q.precise_radius:

      * precise_radius=True (the advanced exact city/state/radius controls
        were used): geocode the city you typed and the job's location text
        (jobscout.geo, offline US city lookup + haversine) and keep the job
        only if it's within radius_miles — falling back to plain text
        matching when either side won't geocode (an international posting,
        an address format the geocoder can't parse, a metro area with no
        exact dataset entry).
      * precise_radius=False (the default — a plain "New York, NY"-style
        location typed into the simple box): skip geocoding altogether and
        go straight to the text match below. This is deliberately loose —
        like typing a location into LinkedIn's search box, not a strict
        radius filter — so it doesn't drop a real match over a few miles.

    Location is optional. Leaving it blank does NOT mean "no location filter
    at all" — it means "anywhere in the US" rather than "anywhere on Earth".
    These employer lists post plenty of non-US roles for the same US
    company (an Indian, Canadian or European office of a US-headquartered
    sponsor), and with no location typed there's nothing else keeping those
    out. Only postings geo.looks_non_us() can clearly place outside the US
    get dropped here; anything ambiguous is kept.
    """
    if q.location_override.strip():
        return True
    if job.work_type == "remote":
        return True
    city = q.city.strip()
    state = q.state.strip()
    if not city and not state:
        return not geo.looks_non_us(job.location)

    if q.precise_radius and city:
        target = geo.geocode(city, state)
        if target:
            job_coords = geo.find_in_text(job.location)
            if job_coords:
                radius = q.radius_miles if q.radius_miles and q.radius_miles > 0 \
                    else DEFAULT_RADIUS_MILES
                return geo.haversine_miles(target[0], target[1],
                                           job_coords[0], job_coords[1]) <= radius
            # Job's location text didn't resolve to coordinates — fall
            # through to the text match below instead of dropping it outright.

    loc = (job.location or "").lower()
    if not loc:
        return False

    city_l = city.lower()
    if city_l and _loc_contains(loc, city_l):
        return True

    state_l = state.lower()
    if state_l:
        candidates = {state_l}
        if state_l in US_STATE_ABBR:
            candidates.add(US_STATE_ABBR[state_l])
        elif state_l in _STATE_ABBR_TO_FULL:
            candidates.add(_STATE_ABBR_TO_FULL[state_l])
        if any(_loc_contains(loc, c) for c in candidates):
            return True

    return False


def passes(job, q):
    """Return (ok, reason). Applied after enrichment, before output."""
    company = (job.company_name or "").lower()
    allow, deny = q.company_allow(), q.company_deny()
    if allow and not any(c in company for c in allow):
        return False, "company"
    if deny and any(c in company for c in deny):
        return False, "company"

    role_terms = role_words(q.role)
    if role_terms:
        role_haystack = f"{job.job_title}\n{job._full_description or job.job_description}".lower()
        if not all(w in role_haystack for w in role_terms):
            return False, "role"

    if not location_ok(job, q):
        return False, "location"

    levels = q.wanted_levels()
    if levels and job.level not in levels:
        return False, "level"

    jts = q.wanted_job_types()
    if jts and job.job_type not in jts:
        return False, "job type"

    wts = q.wanted_work_types()
    if wts and job.work_type not in wts:
        return False, "work type"

    if q.min_salary:
        if not job.salary_min:
            return False, "no salary listed"
        if job.salary_min < q.min_salary:
            return False, "salary"

    cutoff = q.posted_cutoff()
    if cutoff:
        when = parse_posted(job.posted_date)
        if when and when < cutoff:
            return False, "too old"

    text = job._full_description or job.job_description
    scope = {"title": job.job_title,
             "description": text,
             "both": f"{job.job_title}\n{text}"}[q.match_scope]
    if not keyword_ok(scope, q.include_terms(), q.exclude_terms(), q.include_mode):
        return False, "keywords"

    return True, ""


def finalize(job, q, keyword_mode=False):
    """Enrich, filter, then shape the description. Returns (job|None, reason)."""
    enrich(job)
    ok, reason = passes(job, q)
    if not ok:
        return None, reason
    text = job._full_description or job.job_description
    if keyword_mode:
        job.job_description = extract_keywords(text)
        job.responsibilities = ""
        job.qualifications = ""
        note = ""
    else:
        desc, resp, qual, note = shape_description(
            text, q.description_mode, q.max_description_chars)
        job.job_description, job.responsibilities, job.qualifications = desc, resp, qual
    return job, note


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #
CSV_COLUMNS = ["source", "company_name", "job_url", "job_description",
               "responsibilities", "qualifications", "job_title", "location",
               "posted_date", "job_type", "work_type", "level",
               "salary_min", "salary_max", "inferred", "job_id"]


def write_csv(jobs, path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS, quoting=csv.QUOTE_ALL,
                           extrasaction="ignore")
        w.writeheader()
        for j in jobs:
            row = asdict(j)
            row.pop("_full_description", None)
            w.writerow({c: row.get(c, "") for c in CSV_COLUMNS})
    return p.resolve()


def dedupe(jobs):
    seen, out = set(), []
    for j in jobs:
        k = j.dedupe_key()
        if k in seen:
            continue
        seen.add(k)
        out.append(j)
    return out


def interleave(generators):
    """
    Round-robin across per-employer generators.

    Without this, employers are drained in order and the source-wide limit is
    spent on the first one or two — later employers never get reached. Taking
    one job from each in turn means every employer is represented, and any
    that run dry simply drop out of the rotation.
    """
    live = list(generators)
    while live:
        still_going = []
        for gen in live:
            try:
                yield next(gen)
            except StopIteration:
                continue
            still_going.append(gen)
        live = still_going


def per_employer_cap(q, tenant_count):
    """How many jobs one employer may contribute."""
    explicit = int(getattr(q, "per_employer", 0) or 0)
    if explicit > 0:
        return explicit
    if tenant_count <= 1:
        return q.limit
    # spread the budget, but never less than 2 so small employers still show up
    return max(2, -(-q.limit // tenant_count))
