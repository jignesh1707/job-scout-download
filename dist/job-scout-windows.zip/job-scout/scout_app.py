#!/usr/bin/env python3
"""
scout_app.py — local web UI for scout.py / the jobscout package.

Run:
    Windows: double-click start-windows.bat
    Mac:     double-click start-mac.command
(or: pip install -r requirements-scout.txt && python scout_app.py)

Runs on port 5001 so it can sit alongside the LinkedIn tool on 5000.
"""

import json
import os
import re
import queue
import sys
import threading
import time
import uuid
from pathlib import Path

from flask import Flask, Response, abort, jsonify, request, send_file

from jobscout import geo
from jobscout.core import (Query, JOB_TYPES, WORK_TYPES, LEVEL_PRESETS,
                           POSTED_WINDOWS, finalize, dedupe, write_csv)
from jobscout.net import Net, Blocked
from jobscout.sources import SOURCES, resolve, detect_source
from jobscout.sources.gated import Unavailable

BASE = Path(__file__).parent
OUT_DIR = BASE / "runs"
OUT_DIR.mkdir(exist_ok=True)
TENANTS_FILE = BASE / "tenants.json"

app = Flask(__name__)
RUNS = {}
RUNS_LOCK = threading.Lock()

# Tenants fetched via a ResumeToJob scout-access token (see
# /api/tenants/fetch-remote below). In-memory only, on purpose: this is the
# one place a bug could silently defeat the whole point of token-gated
# distribution by writing the curated list back to disk, so read_tenants()
# merges this cache on top of the local file WITHOUT ever calling
# save_tenants() on it.
RTJ_TENANTS_CACHE = {"tenants": {}, "fetches_remaining": None}
RTJ_LOCK = threading.Lock()


# --------------------------------------------------------------------------- #
# Tenants
# --------------------------------------------------------------------------- #
def _read_local_tenants():
    """Disk-only, unmerged. The only tenants view any code path that later
    calls `save_tenants()` may read — see `read_tenants()`'s docstring for
    why the RTJ-fetched cache must never round-trip through this file."""
    if not TENANTS_FILE.exists():
        return {}
    try:
        data = json.loads(TENANTS_FILE.read_text(encoding="utf-8"))
    except ValueError:
        return {}
    return {k: v for k, v in data.items() if not k.startswith("_")}


def read_tenants():
    """Local file entries + the in-memory RTJ-fetched cache, merged for
    display/search only. NEVER pass this merged result to `save_tenants()` —
    doing so would write the token-gated curated list back to disk, defeating
    the entire point of fetching it remotely. Routes that mutate and save
    (`add_tenant`, `remove_tenant`) read `_read_local_tenants()` instead."""
    data = _read_local_tenants()
    with RTJ_LOCK:
        for src, entries in RTJ_TENANTS_CACHE["tenants"].items():
            data.setdefault(src, []).extend(entries)
    return data


def save_tenants(data):
    TENANTS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


# --------------------------------------------------------------------------- #
# Query building
# --------------------------------------------------------------------------- #
def parse_location(text):
    """Split a plain-text location like 'New York, NY', 'Austin, Texas', or
    'Chicago' into (city, state) so the simple Location box can drive the
    same local city/state filter the old City/State fields did — just without
    making the person pick a state from a dropdown first.

    Best-effort only: this feeds the *loose* text-match side of
    location_ok(), never the geocoded radius side, so a city this can't
    confidently split out of the text still gets used as a plain substring
    to match against.
    """
    text = (text or "").strip()
    if not text:
        return "", ""
    parts = [p.strip() for p in text.split(",") if p.strip()]
    if parts and parts[-1].lower() in ("usa", "us", "united states"):
        parts = parts[:-1]
    if len(parts) >= 2 and geo.state_code(parts[-1]):
        return ", ".join(parts[:-1]), parts[-1]
    if len(parts) >= 2:
        return ", ".join(parts), ""
    # No comma — try a trailing state name/abbreviation ("Austin Texas", "Austin TX")
    words = parts[0].split() if parts else text.split()
    for n in (2, 1):
        if len(words) > n and geo.state_code(" ".join(words[-n:])):
            return " ".join(words[:-n]).strip(), " ".join(words[-n:])
    return (parts[0] if parts else text), ""


def make_query(payload):
    def s(key, default=""):
        v = payload.get(key, default)
        return "" if v is None else str(v)

    def i(key, default=0):
        try:
            return int(float(payload.get(key) or default))
        except (TypeError, ValueError):
            return default

    # The simple "Location" box (free text — "New York, NY") wins when filled;
    # it's parsed into city/state and filtered loosely (text match only, no
    # geocoded radius). The advanced City/State fields only take effect when
    # Location is left blank, and turn on the stricter geocoded-radius check.
    loc_text = s("location").strip()
    city_in = s("city").strip()
    state_in = s("state").strip()
    if loc_text:
        city, state, precise = *parse_location(loc_text), False
    elif city_in or state_in:
        city, state, precise = city_in, state_in, True
    else:
        city, state, precise = "", "", False

    q = Query(
        role=s("role").strip(),
        city=city,
        state=state,
        country="United States",
        location_override=s("location_override").strip(),
        radius_miles=i("radius_miles", 25),
        precise_radius=precise,
        level=s("level", "any").strip() or "any",
        include=s("include"),
        exclude=s("exclude"),
        include_mode=s("include_mode", "any") or "any",
        match_scope=s("match_scope", "both") or "both",
        posted=s("posted", "7days") or "7days",
        limit=max(1, min(i("limit", 25), 300)),
        per_employer=max(0, min(i("per_employer", 0), 100)),
        job_types=s("job_types"),
        work_types=s("work_types"),
        min_salary=i("min_salary", 0),
        companies=s("companies"),
        companies_exclude=s("companies_exclude"),
        description_mode=s("description_mode", "sections") or "sections",
        max_description_chars=i("max_description_chars", 0),
        sleep=max(0.5, float(payload.get("sleep") or 1.5)),
        proxy=s("proxy"),
    )
    if q.posted not in POSTED_WINDOWS:
        q.posted = "7days"
    if not q.role and not q.city and not q.state and not q.location_override:
        raise ValueError("Enter a role, or at least a city or state.")
    return q


# --------------------------------------------------------------------------- #
# Worker
# --------------------------------------------------------------------------- #
def worker(run_id, q, wanted, tenant_offset=0):
    run = RUNS[run_id]
    out_q = run["q"]

    # Which employers did each per-employer source actually reach this run?
    # interleave() round-robins across tenants and the search stops the
    # instant "kept" hits the limit, wherever in that rotation it happens to
    # be — so with a long tenant list and a tight limit, employers near the
    # end may never get queried at all. Each source's _one_tenant() emits a
    # "tenant" event as the very first thing it does (before it's even known
    # whether that employer has any matching jobs), so counting distinct
    # (source, company) pairs tells us exactly how far this run got, without
    # guessing from job counts. Kept out of the SSE stream — bookkeeping only.
    reached = {}

    def emit(kind, **data):
        if kind == "tenant":
            reached.setdefault(data["source"], set()).add(data.get("company", ""))
            return
        out_q.put({"type": kind, **data})

    net = Net(sleep=q.sleep, proxy=q.proxy or None, emit=emit)
    tenants = read_tenants()
    jobs, skipped = [], {}
    # Every job seen this run, enriched but *not* filtered — enrich() mutates
    # `job` in place inside finalize() before passes() ever runs, so this
    # holds even for jobs that get dropped below. It's what lets /api/refilter
    # change level/job type/posted/salary/keywords afterwards without paying
    # for a second network fetch: those filters never touched the network to
    # begin with, only role and location did.
    all_jobs = []

    try:
        for name in wanted:
            if run["stop"].is_set():
                break
            spec = SOURCES.get(name)
            if not spec:
                emit("source", name=name, status="error", detail="unknown source")
                continue

            cfgs_all = tenants.get(name, [])
            cfgs = cfgs_all[tenant_offset:] if spec["needs_tenants"] else cfgs_all
            if spec["needs_tenants"] and not cfgs:
                if cfgs_all and tenant_offset:
                    detail = (f"Employer offset {tenant_offset} is past the end "
                              f"of your {len(cfgs_all)} {name} employers — try 0 "
                              f"or a smaller offset")
                else:
                    detail = "no employers added for this source yet"
                emit("source", name=name, status="skipped", detail=detail)
                continue

            emit("source", name=name, status="running",
                 detail=f"{len(cfgs)} employer(s)" if cfgs else "site-wide")
            kept = 0
            keyword_mode = spec.get("output_mode") == "keywords"
            try:
                for job in spec["search"](q, net, cfgs, emit):
                    if run["stop"].is_set():
                        break
                    final, reason = finalize(job, q, keyword_mode=keyword_mode)
                    all_jobs.append(job)   # enriched either way — see note above
                    if final is None:
                        skipped[reason] = skipped.get(reason, 0) + 1
                        # Show *where* a location-skip actually pointed — the
                        # only way to tell a real miss from the filter being
                        # too strict without opening the CSV. work_type is
                        # included too — for a "location" skip specifically,
                        # it settles at a glance whether a remote job is
                        # being wrongly caught (it shouldn't be: remote bypasses
                        # the location check entirely) or whether this is a
                        # genuinely far-away onsite/hybrid posting.
                        where = f" [{job.location.strip()[:40]}]" if job.location else ""
                        wt = f" ({job.work_type})" if job.work_type else ""
                        emit("log", msg=f"  skip ({reason}) {job.job_title[:44]}{where}{wt}")
                        continue
                    jobs.append(final)
                    kept += 1
                    row = {k: v for k, v in final.__dict__.items()
                           if not k.startswith("_")}
                    emit("job", job=row, count=len(jobs))
                    if kept >= q.limit:
                        break
                emit("source", name=name, status="done", detail=f"kept {kept}")
                if spec["needs_tenants"]:
                    reached_n = len(reached.get(name, ()))
                    total_n = len(cfgs)
                    if reached_n < total_n:
                        nxt = tenant_offset + reached_n
                        emit("log", msg=f"  [{name}] reached {reached_n} of {total_n} "
                                        f"employers this run (offset {tenant_offset}) — "
                                        f"set Employer offset to {nxt} next search to "
                                        f"pick up where this left off")
                    else:
                        emit("log", msg=f"  [{name}] reached all {total_n} employers "
                                        f"this run" + (f" (offset {tenant_offset})"
                                        if tenant_offset else ""))
            except Unavailable as e:
                emit("source", name=name, status="gated", detail=str(e))
            except Blocked as e:
                emit("source", name=name, status="blocked", detail=str(e))
            except Exception as e:                              # noqa: BLE001
                emit("source", name=name, status="error",
                     detail=f"{type(e).__name__}: {e}")

        before = len(jobs)
        jobs = dedupe(jobs)
        run["rows"] = jobs
        run["all_jobs"] = all_jobs
        if jobs:
            path = OUT_DIR / f"{run_id}.csv"
            write_csv(jobs, path)
            run["csv"] = str(path)
        run["status"] = "stopped" if run["stop"].is_set() else "done"
        emit("done", count=len(jobs), duplicates=before - len(jobs),
             csv=bool(run.get("csv")), status=run["status"], skipped=skipped)
    except Exception as e:                                      # noqa: BLE001
        run["status"] = "error"
        run["all_jobs"] = all_jobs   # keep whatever was fetched before the crash
        emit("error", message=f"{type(e).__name__}: {e}")
    finally:
        out_q.put(None)


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    return Response((BASE / "scout_ui.html").read_text(encoding="utf-8"),
                    mimetype="text/html")


@app.get("/api/sources")
def list_sources():
    tenants = read_tenants()  # merged (local + RTJ-fetched) — counts include both
    out = []
    for name, spec in SOURCES.items():
        entry = {"name": name, "note": spec["note"],
                 "needs_tenants": spec["needs_tenants"],
                 "count": len(tenants.get(name, []))}
        if spec.get("env_gate"):
            entry["state"] = "ready" if os.environ.get(spec["env_gate"]) else "needs_key"
        elif spec["needs_tenants"]:
            entry["state"] = "ready" if entry["count"] else "needs_tenants"
        else:
            entry["state"] = "ready"
        out.append(entry)
    # `tenants` here is LOCAL-ONLY (not the merged view above) — it feeds the
    # removable employer list in the UI, and its per-source array indices must
    # match what `_read_local_tenants()` sees, or /api/tenants/remove would
    # delete the wrong entry (or a still-live RTJ-fetched one it can't touch
    # at all, since that cache never round-trips through the local file).
    with RTJ_LOCK:
        rtj_count = sum(len(v) for v in RTJ_TENANTS_CACHE["tenants"].values())
    return jsonify(sources=out, tenants=_read_local_tenants(), rtj_fetched_count=rtj_count)


@app.post("/api/tenants/add")
def add_tenant():
    body = request.get_json(force=True, silent=True) or {}
    raw = body.get("url", "") or body.get("urls", "")
    urls = [u.strip() for u in re.split(r"[\s,]+", raw) if u.strip()]
    if not urls:
        return jsonify(error="Paste at least one careers URL."), 400

    data = _read_local_tenants()
    added, skipped, failed = [], [], []
    for url in urls:
        src = detect_source(url)
        if not src:
            failed.append(url)
            continue
        cfg = SOURCES[src]["parse_url"](url)
        if not cfg:
            failed.append(url)
            continue
        entries = data.setdefault(src, [])
        # Dedup on identity fields only (everything except "company"):
        # "company" is derived by canonical_company() from the current
        # contents of employer_names.csv, which can change between when a
        # tenant was first added and now (e.g. once a proper canonical name
        # gets backfilled) even though the tenant itself
        # (host/tenant/token/company_id/...) is the same. Comparing full
        # dicts would treat that as a new tenant and add a duplicate entry.
        # Same idea as scripts/seed_tenants.py.
        cfg_identity = {k: v for k, v in cfg.items() if k != "company"}
        if any({k: v for k, v in e.items() if k != "company"} == cfg_identity
               for e in entries):
            skipped.append(cfg.get("company") or url)
            continue
        entries.append(cfg)
        added.append({"source": src, **cfg})

    if added:
        save_tenants(data)
    if not added and len(urls) == 1:
        if skipped:
            return jsonify(error=f"{skipped[0]} is already in the list."), 400
        return jsonify(error="That URL isn't a system I recognise. Supported: "
                             "myworkdayjobs.com, icims.com, taleo.net, "
                             "oraclecloud.com, greenhouse.io, "
                             "smartrecruiters.com"), 400
    return jsonify(added=added, skipped=skipped, failed=failed,
                   tenants=data,
                   source=added[0]["source"] if added else None,
                   entry=added[0] if added else None)


def redeem_token(token, api_url=None):
    """Fetch the curated list with a scout-access token into the in-memory
    cache. Returns the total employer count; raises RtjTokenError."""
    from jobscout.rtj_client import DEFAULT_API_URL, load_tenants_remote

    raw = load_tenants_remote(token, api_url or DEFAULT_API_URL)
    tenants = {resolve(k): v for k, v in raw.items()}
    with RTJ_LOCK:
        RTJ_TENANTS_CACHE["tenants"] = tenants
    return sum(len(v) for v in tenants.values())


@app.post("/api/tenants/fetch-remote")
def fetch_remote_tenants():
    """Redeem a ResumeToJob scout-access token for the curated tenants list.

    Stores the result in RTJ_TENANTS_CACHE (in-memory only) — never
    save_tenants(), never touches tenants.json. See that global's comment
    for why.
    """
    from jobscout.rtj_client import RtjTokenError

    body = request.get_json(force=True, silent=True) or {}
    token = (body.get("token") or "").strip()
    api_url = (body.get("api_url") or "").strip() or None

    if not token:
        return jsonify(error="Paste your ResumeToJob access token."), 400

    try:
        fetched_count = redeem_token(token, api_url)
    except RtjTokenError as e:
        return jsonify(error=str(e)), 400

    return jsonify(ok=True, rtj_fetched_count=fetched_count)


@app.post("/api/tenants/remove")
def remove_tenant():
    body = request.get_json(force=True, silent=True) or {}
    src, idx = body.get("source"), body.get("index")
    data = _read_local_tenants()
    try:
        data[src].pop(int(idx))
    except (KeyError, IndexError, TypeError, ValueError):
        return jsonify(error="No such entry."), 400
    if not data[src]:
        data.pop(src)
    save_tenants(data)
    return jsonify(tenants=data)


@app.post("/api/run")
def start_run():
    payload = request.get_json(force=True, silent=True) or {}
    try:
        q = make_query(payload)
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400

    wanted = [resolve(s) for s in str(payload.get("sources", "")).split(",") if s.strip()]
    if not wanted:
        return jsonify(error="Pick at least one source."), 400

    try:
        tenant_offset = max(0, int(float(payload.get("tenant_offset") or 0)))
    except (TypeError, ValueError):
        tenant_offset = 0

    run_id = uuid.uuid4().hex[:12]
    with RUNS_LOCK:
        RUNS[run_id] = {"q": queue.Queue(), "rows": [], "csv": None,
                        "stop": threading.Event(), "status": "running",
                        "started": time.time()}
    threading.Thread(target=worker, args=(run_id, q, wanted, tenant_offset),
                     daemon=True).start()
    return jsonify(run_id=run_id, sources=wanted, limit=q.limit,
                   location=q.location_string(), tenant_offset=tenant_offset)


@app.post("/api/refilter/<run_id>")
def refilter(run_id):
    """Re-apply every *local* filter — level, job type, work type, posted,
    min salary, keywords, companies, description shaping — to a run's
    already-fetched, already-enriched jobs. No network calls: role and
    location are what actually shaped the search each source ran, so this
    only re-checks the local role/location backstop against jobs already on
    hand. To search a different role, location, or employer set, start a new
    /api/run — this just re-slices what that run already brought back.
    """
    run = RUNS.get(run_id)
    if run is None:
        abort(404)
    all_jobs = run.get("all_jobs")
    if not all_jobs:
        return jsonify(error="This run has no fetched jobs to filter yet — "
                             "wait for it to finish, or run a search first."), 400

    payload = request.get_json(force=True, silent=True) or {}
    try:
        q = make_query(payload)
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400

    jobs, skipped = [], {}
    for job in all_jobs:
        keyword_mode = SOURCES.get(job.source, {}).get("output_mode") == "keywords"
        final, reason = finalize(job, q, keyword_mode=keyword_mode)
        if final is None:
            skipped[reason] = skipped.get(reason, 0) + 1
            continue
        jobs.append(final)

    before = len(jobs)
    jobs = dedupe(jobs)
    run["rows"] = jobs
    if jobs:
        path = OUT_DIR / f"{run_id}.csv"
        write_csv(jobs, path)
        run["csv"] = str(path)
    else:
        run["csv"] = None

    rows = [{k: v for k, v in j.__dict__.items() if not k.startswith("_")} for j in jobs]
    return jsonify(jobs=rows, count=len(jobs), duplicates=before - len(jobs),
                   csv=bool(run.get("csv")), skipped=skipped, scanned=len(all_jobs))


@app.get("/api/stream/<run_id>")
def stream(run_id):
    run = RUNS.get(run_id)
    if run is None:
        abort(404)

    def gen():
        yield ": connected\n\n"
        while True:
            try:
                item = run["q"].get(timeout=15)
            except queue.Empty:
                yield ": keep-alive\n\n"
                continue
            if item is None:
                break
            yield f"data: {json.dumps(item)}\n\n"

    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


@app.post("/api/stop/<run_id>")
def stop_run(run_id):
    run = RUNS.get(run_id)
    if run is None:
        abort(404)
    run["stop"].set()
    return jsonify(ok=True)


@app.get("/api/download/<run_id>")
def download(run_id):
    run = RUNS.get(run_id)
    if not run or not run.get("csv"):
        abort(404)
    return send_file(run["csv"], as_attachment=True,
                     download_name=f"jobs_multi_{run_id}.csv")


if __name__ == "__main__":
    # Plain "cmd.exe" on Windows defaults to a cp1252 console, which can't
    # encode the arrow below and crashes on startup before the server ever
    # binds. reconfigure() is a no-op failure mode (falls back silently) on
    # any stdout that doesn't support it, so this is safe everywhere.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print("\n  Multi-source job search  ->  http://127.0.0.1:5001\n")
    # The start scripts ask for the token in the terminal and hand it over
    # via the environment, so students never have to find a paste box.
    _tok = os.environ.pop("RTJ_TOKEN", "").strip()
    if _tok:
        from jobscout.rtj_client import RtjTokenError
        try:
            print(f"  Employer list loaded: {redeem_token(_tok)} employers.\n")
        except RtjTokenError as e:
            print(f"  Could not load the employer list: {e}\n"
                  "  You can paste the token again in the browser page.\n")
    app.run(host="127.0.0.1", port=5001, threaded=True, debug=False)
